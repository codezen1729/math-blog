import type { Metadata } from 'next';
import 'katex/dist/katex.min.css';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'The Iterated Plane · S. Viswanathan',
    template: '%s · The Iterated Plane',
  },
  description: 'A guided mathematical weblog in complex analysis, topology, geometry, K-theory, and dynamics.',
  applicationName: 'The Iterated Plane',
  authors: [{ name: 'S. Viswanathan' }],
  icons: { icon: '/favicon.svg' },
  openGraph: {
    title: 'The Iterated Plane',
    description: 'Interactive complex dynamics and selected mathematical expositions by S. Viswanathan.',
    type: 'website',
    images: [{ url: '/og.png', width: 1200, height: 630, alt: 'The Iterated Plane' }],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
