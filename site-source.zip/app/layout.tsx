import type { Metadata } from 'next';
import 'katex/dist/katex.min.css';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'S. Viswanathan · Mathematics',
    template: '%s · S. Viswanathan',
  },
  description: 'Research, teaching, mathematical expositions, and a laboratory of complex dynamics.',
  applicationName: 'S. Viswanathan',
  authors: [{ name: 'S. Viswanathan' }],
  icons: { icon: '/favicon.svg' },
  openGraph: {
    title: 'S. Viswanathan · Mathematics',
    description: 'Interactive complex dynamics and selected mathematical expositions by S. Viswanathan.',
    type: 'website',
    images: [{ url: '/og.png', width: 1730, height: 909, alt: 'S. Viswanathan — Mathematics · Complex dynamics' }],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
