import type { Metadata } from 'next';
import 'katex/dist/katex.min.css';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'S. Viswanathan’s Mathematical Blog',
    template: '%s · S. Viswanathan’s Mathematical Blog',
  },
  description: 'Mathematical writing by S. Viswanathan: K-theory, complex dynamics, surfaces and curves, and standard tools in complex analysis.',
  applicationName: 'S. Viswanathan’s Mathematical Blog',
  authors: [{ name: 'S. Viswanathan' }],
  icons: { icon: '/favicon.svg' },
  openGraph: {
    title: 'S. Viswanathan’s Mathematical Blog',
    description: 'Interactive complex dynamics and selected mathematical expositions by S. Viswanathan.',
    type: 'website',
    images: [{ url: '/og.png', width: 1730, height: 909, alt: 'S. Viswanathan — Mathematics · Complex dynamics' }],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
