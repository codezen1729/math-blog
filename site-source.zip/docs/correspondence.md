# Example 4 correspondence laboratory

Source: Y. Luo, M. Mj, S. Mukherjee, *Teichmüller spaces, polynomial loci, and degeneration in spaces of algebraic correspondences*, [arXiv:2504.13107v2](https://arxiv.org/pdf/2504.13107v2), Example 4 (p.30), Definition 3.1 and Theorem 3.5 / equation (3.2). Also [*Matings, holomorphic correspondences, and a Bers slice*](https://jep.centre-mersenne.org/item/10.5802/jep.315.pdf), §§6.4 and 7.1. These are original computed images, not copied figures.

## Normalization and scope

R_c(z) = z + c/z − c/(3z³) + 1/(5z⁵).

The correspondence is (R_c(x) − R_c(1/y))/(x − 1/y) = 0; the quotient removes the trivial reciprocal branch. The involution is holomorphic η(z)=1/z, **without conjugation**.

This implementation uses **real c in [−3/5,3/5]**, including the pinched endpoints, with D the exterior unit disk on the sphere. It is not a parametrization of the full complex Bers locus. In particular D cannot be assumed to be the exterior unit disk for arbitrary complex c.

Let Ω=R_c(D), an unbounded domain, and let ζ be the unique exterior root of R_c(ζ)=w. On Ω the associated B-involution is F_c(w)=R_c(1/ζ). The rank-zero tile is the bounded side of γ(t)=R_c(exp(it)); cusp points are excluded. The sets shown are pulled back through R_c from the F-plane. We do not iterate R_c as if it were a polynomial, and do not iterate all correspondence branches indiscriminately.

- Tiling set: the lifted orbit reaches the interior of the rank-zero tile.
- Non-escaping set: complement of the tiling set, including the limit set. In this normalization its interior contains two polynomial pieces, with 0 and infinity in the lifted set. Approaching infinity in the F-plane is **not** tiling escape.
- Limit set: their common boundary. The interface between numerically resolved T/K sample pixels provides only a finite-resolution approximation.

“Filled limit set” in §8 of the paper is different from the non-escaping set. This exhibit does not use that potentially confusing term.

## Why this real slice has a usable exterior inverse

This is an implementation-side verification, not a claim that Example 4 explicitly identifies the full real locus.

R′_c(z)=(z²−1)(z⁴+(1−c)z²+1)/z⁶. For |c|<3/5 there are six simple critical points on the unit circle. Writing u=cos(t), s=sin(t), the boundary coordinates are

X = u[(16/5)u⁴ − (4+4c/3)u² + 2+2c],
Y = (4/15)s³(15−5c−12s²).

In this range X has the sign of u and Y the sign of s, so different open quadrants do not meet. In the first quadrant the only cusp is at θ=½ arccos((c−1)/2), between π/4 and π/2. The derivative is

γ′(t)=−2 sin(t) exp(−2it)[2 cos(2t)+1−c].

On [0,π/4], [π/4,θ], [θ,π/2] the coordinate directions are respectively (X↓,Y↑), (X↑,Y↑), (X↓,Y↓). The slope −tan(2t) decreases on the latter two arcs. Comparing their slopes from their shared cusp shows the last arc lies above the middle arc at common X. The first and middle arcs are disjoint by their Y ranges; comparing through the middle arc separates the first and last arcs. Thus the first-quadrant arc is simple. Symmetry gives a Jordan boundary. The argument principle then gives univalence on the exterior disk, normalized by R_c(z)∼z at infinity.

At c=3/5, R_c(i)=R_c(−i)=0: the fundamental tile interior has two components. At c=−3/5, R_c(e^{iπ/4})=R_c(e^{3iπ/4})=4√2 i/5, with a conjugate lower contact: the fundamental tile interior has three components. These counts refer to the rank-zero tile, not the full lifted tiling set. Exterior univalence persists at both endpoints by the nonconstant locally uniform limit theorem for univalent functions. The boundary is no longer Jordan. Boundary sampling uses a multiple of eight so the contact parameters are sampled exactly.

The range cannot be extended past these endpoints while retaining this inverse model. For c>3/5, r⁶−cr⁴−(c/3)r²−1/5 has a root r>1, giving R_c(ir)=R_c(−ir)=0. For c<−3/5, the analogous polynomial r⁶+cr⁴+(c/3)r²−1/5 has a root r>1, giving equal images of distinct exterior points at angles π/4 and 3π/4. Thus exterior univalence fails beyond the selected slice.

The six displayed critical points have arguments 0, θ, π−θ, π, π+θ, 2π−θ. They lie on the correspondence limit set. These are not **all** critical points of R_c: the pole at zero is also critical.

## Numerical safeguards

The polygon approximating γ has uniform chord-deviation bound (6+4|c|)(2π/N)²/8, since sup|γ″|≤6+4|c|. A point within that distance plus a floating-point allowance is left unresolved. Otherwise polygon winding detects the same side of the true curve. A y-index over segments speeds this calculation without changing parity or distance checks.

The inverse solver uses exterior-constrained damped Newton iteration, multiple initial directions, residual checks, derivative checks, and separation from |ζ|=1. The inverse equation is ζ⁶−wζ⁵+cζ⁴−(c/3)ζ²+1/5=0. Exterior univalence ensures there is at most one eligible root; solver failures remain unresolved.

For |c|≤0.6 and |ζ|≥1, |R_c(ζ)−ζ|≤1. If |w|≥4, the exterior inverse satisfies r=|ζ|≥3 and

|F_c(w)| ≥ r⁵/5−0.6r³/3−0.6r−1/r > 2(r+1) ≥ 2|w|.

Thus |w|≥4 is a forward-invariant infinity-basin trap. Direct lower bounds on |R_c(z)| also give this trap for |z|<0.1 and |z|>5. The designated sphere input {re:Infinity, im:0} is handled explicitly; NaN/failed arithmetic is not silently treated as infinity.

Reaching the iteration cap never automatically assigns membership in K or Λ. Boundary uncertainty, failed inverse solving, and iteration exhaustion remain grey. Orbit errors are not propagated by interval arithmetic: all rendered classifications are numerical approximations, **not certified pointwise membership proofs**.

The limit raster marks resolved pixels adjacent in four directions to pixels of the other resolved type. It neither fills unresolved areas as limit set nor pretends the smooth rank-zero tile boundary is Λ. The interface can have gaps and miss subpixel features.

## Interface and verification

A module worker computes one shared grid for three colour layers. Parameter, resolution, depth and viewport changes cancel obsolete work. During recomputation old images are marked with their old c; cusp markers use that same c. Point-inspector text states the requested c separately. All views share pinch, drag, wheel mode, and keyboard navigation. Worker failures have a visible retry action; canvas failures leave the point inspector available. The mobile layout stacks the three panels.

`scripts/correspondence.test.mjs` checks algebra, reciprocal convention, critical points, inverse roots, the conservative boundary band, infinity semantics, iteration exhaustion, symmetry, six lifted tile sectors, interface construction, input limits, accessible formula rendering and workbench inclusion. Existing quadratic-explorer and blog tests remain unchanged. No manuscript or generated blog-post wording is modified by this feature.
