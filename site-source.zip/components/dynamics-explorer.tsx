'use client';

/* oxlint-disable jsx-a11y/prefer-tag-over-role -- The two-dimensional interactive plots expose keyboard controls as application regions. */
/* oxlint-disable jsx-a11y/no-static-element-interactions -- The dynamic role is application for the keyboard-interactive plot and img for the read-only slice. */

import { useEffect, useId, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent } from 'react';
import { Crosshair, Minus, Pause, Play, Plus, RotateCcw, StepForward } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { formatComplex, fractalColour, JULIA_VIEW, PARAMETER_VIEW, planePoint, planePosition, quadraticEscape, quadraticOrbit, zoomView } from '@/lib/dynamics';
import type { Complex, PlaneView } from '@/lib/dynamics';

const ORIGIN = { re: 0, im: 0 };
const PRESETS = [
  { name: 'Rabbit', re: -0.122561, im: 0.744862 },
  { name: 'Basilica', re: -1, im: 0 },
  { name: 'Dendrite', re: 0, im: 1 },
  { name: 'Cantor dust', re: -0.75, im: 0.3 },
];

function CoordinateForm({ label, value, onChange }: { label: string; value: Complex; onChange: (point: Complex) => void }) {
  return <form className="coordinate-form" key={`${value.re},${value.im}`} onSubmit={(event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const re = Number(form.get('real'));
    const im = Number(form.get('imaginary'));
    if (Number.isFinite(re) && Number.isFinite(im)) onChange({ re, im });
  }}>
    <span className="coordinate-label">{label}</span>
    <Input name="real" type="number" step="any" required defaultValue={value.re.toString()} aria-label={`${label} real part`} />
    <span>+</span>
    <Input name="imaginary" type="number" step="any" required defaultValue={value.im.toString()} aria-label={`${label} imaginary part`} />
    <span>i</span>
    <Button variant="outline" size="sm" type="submit">Set</Button>
  </form>;
}

function PlotMarker({ view, point, label, kind }: { view: PlaneView; point: Complex; label: string; kind: string }) {
  const { x, y } = planePosition(view, point);
  if (x < 0 || x > 1 || y < 0 || y > 1) return null;
  return <span className={`plot-marker marker-${kind}`} style={{ left: `${100 * x}%`, top: `${100 * y}%` }}><i /><b>{label}</b></span>;
}

export function FractalPlane({ mode, c, view, iterations, selected, onSelect, orbit = [], activeStep = 0, renderEscape, onRendered }: {
  mode: 'parameter' | 'julia' | 'motion'; c: Complex; view: PlaneView; iterations: number;
  selected?: Complex; onSelect?: (point: Complex) => void; orbit?: Complex[]; activeStep?: number;
  renderEscape?: (re: number, im: number, limit: number) => number;
  onRendered?: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const pendingTap = useRef<{ x: number; y: number } | null>(null);
  const [width, setWidth] = useState(440);
  const [busy, setBusy] = useState(true);
  const [canvasError, setCanvasError] = useState(false);
  const id = useId();
  useEffect(() => {
    if (!frameRef.current) return;
    const observer = new ResizeObserver(([entry]) => setWidth(Math.max(180, Math.min(640, Math.round(entry.contentRect.width * Math.min(window.devicePixelRatio || 1, 1.4))))));
    observer.observe(frameRef.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext('2d');
    if (!canvas || !context) { setCanvasError(true); return; }
    const pixels = context.createImageData(width, width);
    let row = 0;
    let frame = 0;
    setBusy(true);
    const draw = () => {
      const start = performance.now();
      while (row < width && performance.now() - start < 12) {
        const im = view.im + (0.5 - (row + 0.5) / width) * view.span;
        for (let x = 0; x < width; x++) {
          const re = view.re + ((x + 0.5) / width - 0.5) * view.span;
          const escape = renderEscape ? renderEscape(re, im, iterations) : mode === 'parameter'
            ? quadraticEscape(0, 0, re, im, iterations)
            : quadraticEscape(re, im, c.re, c.im, iterations);
          const colour = fractalColour(escape);
          const offset = 4 * (row * width + x);
          pixels.data[offset] = colour[0];
          pixels.data[offset + 1] = colour[1];
          pixels.data[offset + 2] = colour[2];
          pixels.data[offset + 3] = 255;
        }
        row++;
      }
      if (row < width) frame = requestAnimationFrame(draw);
      else {
        if (canvas.width !== width) { canvas.width = width; canvas.height = width; }
        context.putImageData(pixels, 0, 0);
        setBusy(false); onRendered?.();
      }
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [width, mode, c.re, c.im, view.re, view.im, view.span, iterations, renderEscape, onRendered]);

  const choose = (event: PointerEvent<HTMLDivElement>) => {
    const tap = pendingTap.current;
    pendingTap.current = null;
    if (!onSelect || !tap || Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 8) return;
    const box = event.currentTarget.getBoundingClientRect();
    onSelect(planePoint(view, (event.clientX - box.left) / box.width, (event.clientY - box.top) / box.height));
  };
  const move = (event: KeyboardEvent<HTMLDivElement>) => {
    if (!onSelect || !selected) return;
    const step = view.span / (event.shiftKey ? 500 : 100);
    const delta: Record<string, Complex> = { ArrowLeft: { re: -step, im: 0 }, ArrowRight: { re: step, im: 0 }, ArrowUp: { re: 0, im: step }, ArrowDown: { re: 0, im: -step } };
    if (delta[event.key]) { event.preventDefault(); onSelect({ re: selected.re + delta[event.key].re, im: selected.im + delta[event.key].im }); }
  };
  const displayed = orbit.slice(0, activeStep + 1).map((z) => planePosition(view, z));
  const originPosition = planePosition(view, ORIGIN);
  return <>
    <div className={`fractal-plot plot-${mode}`} ref={frameRef} onPointerDown={(event) => { if (event.button === 0) pendingTap.current = { x: event.clientX, y: event.clientY }; }} onPointerUp={choose} onPointerCancel={() => { pendingTap.current = null; }} onKeyDown={move} tabIndex={onSelect ? 0 : undefined} role={onSelect ? "application" : "img"}
      aria-label={`${mode === 'parameter' ? 'Mandelbrot parameter plane. Choose c' : mode === 'julia' ? 'Julia dynamical plane. Choose the initial point z zero' : 'Connectedness locus'}. ${onSelect ? 'Click or use arrow keys; Shift gives finer steps.' : ''}`} aria-describedby={id} aria-busy={busy}>
      <canvas ref={canvasRef} aria-hidden="true" />
      <div className="plot-axes" aria-hidden="true">
        {originPosition.x >= 0 && originPosition.x <= 1 && <i className="axis-imaginary" style={{ left: `${originPosition.x * 100}%` }} />}
        {originPosition.y >= 0 && originPosition.y <= 1 && <i className="axis-real" style={{ top: `${originPosition.y * 100}%` }} />}
        <span className="axis-label-real">Re</span><span className="axis-label-imaginary">Im</span>
      </div>
      {mode === 'parameter' && selected && <PlotMarker view={view} point={selected} label="c" kind="parameter" />}
      {mode === 'julia' && <>
        <svg className="orbit-overlay" viewBox="0 0 1000 1000" aria-hidden="true">
          <polyline points={displayed.map(({ x, y }) => `${x * 1000},${y * 1000}`).join(' ')} />
          {displayed.map(({ x, y }, n) => <circle key={n} cx={x * 1000} cy={y * 1000} r={n === displayed.length - 1 ? 7 : 4} />)}
        </svg>
        <PlotMarker view={view} point={ORIGIN} label="0 · critical" kind="critical" />
        <PlotMarker view={view} point={c} label="c" kind="value" />
        {selected && (selected.re !== 0 || selected.im !== 0) && <PlotMarker view={view} point={selected} label="z₀" kind="seed" />}
      </>}
      {canvasError && <p className="plot-error">Canvas is unavailable. Orbit coordinates remain available below.</p>}
      {busy && !canvasError && <span className="plot-rendering">Computing…</span>}
    </div>
    <p className="plot-bounds" id={id}><span>Re [{(view.re - view.span / 2).toFixed(3)}, {(view.re + view.span / 2).toFixed(3)}]</span><span>Im [{(view.im - view.span / 2).toFixed(3)}, {(view.im + view.span / 2).toFixed(3)}]</span></p>
  </>;
}

function ZoomControls({ label, onZoom, onReset }: { label: string; onZoom: (factor: number) => void; onReset: () => void }) {
  return <div className="plot-zoom" aria-label={`${label} view controls`}>
    <Button variant="outline" size="icon-sm" aria-label={`Zoom in ${label} around selected point`} onClick={() => onZoom(0.5)}><Plus /></Button>
    <Button variant="outline" size="icon-sm" aria-label={`Zoom out ${label}`} onClick={() => onZoom(2)}><Minus /></Button>
    <Button variant="outline" size="icon-sm" aria-label={`Reset ${label} view`} onClick={onReset}><RotateCcw /></Button>
  </div>;
}

export function MandelbrotJuliaExplorer() {
  const [c, setC] = useState<Complex>({ re: -0.122561, im: 0.744862 });
  const [seed, setSeed] = useState<Complex>(ORIGIN);
  const [parameterView, setParameterView] = useState(PARAMETER_VIEW);
  const [juliaView, setJuliaView] = useState(JULIA_VIEW);
  const [iterations, setIterations] = useState(180);
  const [step, setStep] = useState(24);
  const [playing, setPlaying] = useState(false);
  const id = useId();
  const orbit = useMemo(() => quadraticOrbit(seed, c, 80), [seed, c]);
  const criticalOrbit = useMemo(() => quadraticOrbit(ORIGIN, c, iterations), [c, iterations]);
  const last = orbit.points.length - 1;
  const shown = Math.min(step, last);
  const chooseC = (point: Complex) => { setC(point); setPlaying(false); };
  const chooseSeed = (point: Complex) => { setSeed(point); setStep(24); setPlaying(false); };
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => setStep((n) => {
      if (n >= last) { setPlaying(false); return last; }
      return n + 1;
    }), 240);
    return () => clearInterval(timer);
  }, [playing, last]);
  return <section className="dynamics-workbench" aria-labelledby={`${id}-title`}>
    <header className="workbench-heading"><div><p className="kicker">01 / Parameter & dynamical planes</p><h2 id={`${id}-title`}>The quadratic explorer</h2></div><span className="workbench-equation">z ↦ z² + c</span></header>
    <p className="workbench-instructions">Choose <i>c</i> on the left. Its filled Julia set appears on the right. Click there to follow an orbit.</p>
    <div className="linked-planes">
      <section className="plane-panel" aria-label="Mandelbrot explorer">
        <header><div><h3>Mandelbrot set</h3><span>Parameter plane · click to pin c</span></div><ZoomControls label="Mandelbrot" onZoom={(factor) => setParameterView(zoomView(parameterView, c, factor))} onReset={() => setParameterView(PARAMETER_VIEW)} /></header>
        <FractalPlane mode="parameter" c={ORIGIN} view={parameterView} iterations={iterations} selected={c} onSelect={chooseC} />
        <CoordinateForm label="c" value={c} onChange={chooseC} />
      </section>
      <section className="plane-panel" aria-label="Julia explorer">
        <header><div><h3>Filled Julia set</h3><span>Dynamical plane · click to choose z₀</span></div><ZoomControls label="Julia" onZoom={(factor) => setJuliaView(zoomView(juliaView, seed, factor))} onReset={() => setJuliaView(JULIA_VIEW)} /></header>
        <FractalPlane mode="julia" c={c} view={juliaView} iterations={iterations} selected={seed} onSelect={chooseSeed} orbit={orbit.points} activeStep={shown} />
        <CoordinateForm label="z₀" value={seed} onChange={chooseSeed} />
      </section>
    </div>
    <div className="explorer-options">
      <div className="preset-row" aria-label="Quadratic presets">{PRESETS.map((preset) => <Button key={preset.name} size="sm" variant="outline" aria-pressed={Math.abs(c.re - preset.re) + Math.abs(c.im - preset.im) < 0.000001} onClick={() => { chooseC({ re: preset.re, im: preset.im }); setParameterView(PARAMETER_VIEW); setJuliaView(JULIA_VIEW); }}>{preset.name}</Button>)}</div>
      <label className="detail-control">Detail <select aria-label="Fractal iteration limit" value={iterations} onChange={(event) => setIterations(Number(event.target.value))}><option value={100}>100 iterations</option><option value={180}>180 iterations</option><option value={350}>350 iterations</option><option value={700}>700 iterations</option></select></label>
    </div>
    <div className="orbit-console">
      <div className="orbit-title"><h3>Follow the orbit</h3><Button size="sm" variant="outline" onClick={() => chooseSeed(ORIGIN)}><Crosshair /> Start at the critical point</Button></div>
      <div className="orbit-transport">
        <Button variant="outline" size="icon" aria-label={playing ? 'Pause orbit' : 'Play orbit'} onClick={() => { if (playing) setPlaying(false); else { if (shown >= last) setStep(0); setPlaying(true); } }}>{playing ? <Pause /> : <Play />}</Button>
        <Button variant="outline" size="icon" aria-label="Next orbit iterate" disabled={shown >= last} onClick={() => { setPlaying(false); setStep(shown + 1); }}><StepForward /></Button>
        <Button variant="outline" size="icon" aria-label="Restart orbit" onClick={() => { setPlaying(false); setStep(0); }}><RotateCcw /></Button>
        <span id={`${id}-step-label`} className="sr-only">Displayed orbit iterate</span><Slider value={[shown]} min={0} max={Math.max(1, last)} step={1} aria-labelledby={`${id}-step-label`} onValueChange={(value) => { setPlaying(false); setStep(Array.isArray(value) ? value[0] : value); }} />
        <output>n = {shown}</output>
      </div>
      <div className="orbit-readout" aria-live="polite"><strong>z{String(shown).replace(/\d/g, (n) => '₀₁₂₃₄₅₆₇₈₉'[Number(n)])} = {formatComplex(orbit.points[shown])}</strong><span>{orbit.escapedAt !== null ? `Orbit escaped at n = ${orbit.escapedAt}.` : 'No escape detected in 80 iterates.'}</span></div>
      <details className="orbit-table"><summary>Orbit coordinates</summary><div><table><thead><tr><th>n</th><th>Re zₙ</th><th>Im zₙ</th></tr></thead><tbody>{orbit.points.slice(0, shown + 1).map((z, n) => <tr key={n}><td>{n}</td><td>{z.re.toFixed(7)}</td><td>{z.im.toFixed(7)}</td></tr>)}</tbody></table></div></details>
    </div>
    <p className="simulation-caption"><span className="critical-key" /> Critical point: 0. <span className="value-key" /> Critical value: c. {criticalOrbit.escapedAt !== null ? `The critical orbit escapes at n = ${criticalOrbit.escapedAt}.` : `The critical orbit has not escaped in ${iterations} iterates.`} Dark pixels have not escaped within the iteration limit; they approximate filled sets. The Julia set is the boundary. Zoom is centred on the selected point.</p>
  </section>;
}
