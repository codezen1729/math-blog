'use client';

/* oxlint-disable jsx-a11y/prefer-tag-over-role -- The two-dimensional multiplier picker is a keyboard-controlled application region. */
/* oxlint-disable jsx-a11y/no-noninteractive-element-interactions, jsx-a11y/no-noninteractive-tabindex -- role=application intentionally captures arrow keys for a two-dimensional selector; the radius also has a conventional labelled slider. */

import { useCallback, useEffect, useId, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent } from 'react';
import { Minus, Pause, Play, Plus, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { FractalPlane } from '@/components/dynamics-explorer';
import { formatComplex, PARAMETER_VIEW, sliceEscape, zoomView } from '@/lib/dynamics';
import type { Complex } from '@/lib/dynamics';

const ZERO = { re: 0, im: 0 };
const MAX_RADIUS = 0.85;

export function MandelbrotMotion() {
  const [mu, setMu] = useState<Complex>(ZERO);
  const [view, setView] = useState(PARAMETER_VIEW);
  const [iterations, setIterations] = useState(180);
  const [playing, setPlaying] = useState(false);
  const [rendered, setRendered] = useState(0);
  const id = useId();
  const diskRef = useRef<HTMLDivElement>(null);
  const radius = Math.hypot(mu.re, mu.im);
  const angle = Math.atan2(mu.im, mu.re);
  const choose = (point: Complex) => {
    const modulus = Math.hypot(point.re, point.im);
    const scale = modulus > MAX_RADIUS ? MAX_RADIUS / modulus : 1;
    setMu({ re: point.re * scale, im: point.im * scale });
    setPlaying(false);
  };
  const move = (event: PointerEvent<HTMLDivElement>) => {
    if (event.type === 'pointermove' && event.buttons !== 1) return;
    if (event.type === 'pointerdown') event.currentTarget.setPointerCapture(event.pointerId);
    const box = event.currentTarget.getBoundingClientRect();
    choose({ re: 2.3 * ((event.clientX - box.left) / box.width - 0.5), im: 2.3 * (0.5 - (event.clientY - box.top) / box.height) });
  };
  const key = (event: KeyboardEvent<HTMLDivElement>) => {
    const step = event.shiftKey ? 0.005 : 0.025;
    const movements: Record<string, Complex> = { ArrowRight: { re: step, im: 0 }, ArrowLeft: { re: -step, im: 0 }, ArrowUp: { re: 0, im: step }, ArrowDown: { re: 0, im: -step } };
    if (movements[event.key]) { event.preventDefault(); choose({ re: mu.re + movements[event.key].re, im: mu.im + movements[event.key].im }); }
  };
  const escape = useCallback((re: number, im: number, limit: number) => sliceEscape({ re, im }, mu, limit), [mu]);
  const onRendered = useCallback(() => setRendered((n) => n + 1), []);
  useEffect(() => {
    if (!playing) return;
    const timer = setTimeout(() => {
      setMu((previous) => {
        const r = Math.hypot(previous.re, previous.im) || 0.5;
        const theta = Math.atan2(previous.im, previous.re) + Math.PI / 24;
        return { re: r * Math.cos(theta), im: r * Math.sin(theta) };
      });
    }, 600);
    return () => clearTimeout(timer);
  }, [playing, rendered]);
  return <section className="dynamics-workbench motion-workbench" aria-labelledby={`${id}-title`}>
    <header className="workbench-heading"><div><p className="kicker">02 / The multiplier disk</p><h2 id={`${id}-title`}>A moving Mandelbrot set</h2></div><span className="workbench-equation">μ ∈ 𝔻</span></header>
    <p className="workbench-instructions">Move the multiplier μ inside the disk to explore the connectedness locus in Per₁(μ).</p>
    <div className="motion-layout">
      <div className="multiplier-controls">
        <h3>The unit disk</h3>
        <div className="multiplier-disk" ref={diskRef} role="application" tabIndex={0} onPointerDown={move} onPointerMove={move} onKeyDown={key} aria-label="Choose the fixed-point multiplier in the unit disk. Click, drag, or use arrow keys. Radius is limited to 0.85.">
          <svg viewBox="-1.15 -1.15 2.3 2.3" aria-hidden="true"><circle className="unit-disk-boundary" r="1" /><circle className="disk-computing-boundary" r={MAX_RADIUS} /><path className="disk-axes" d="M-1.06 0H1.06M0 -1.06V1.06" /><circle className="disk-radius" r={radius} /><line className="disk-ray" x1="0" y1="0" x2={mu.re} y2={-mu.im} /><circle className="disk-point" cx={mu.re} cy={-mu.im} r=".04" /></svg>
          <span className="disk-label disk-one">1</span><span className="disk-label disk-i">i</span><span className="disk-label disk-zero">0</span>
        </div>
        <output className="multiplier-value" aria-live="polite">μ = {formatComplex(mu, 3)}</output>
        <div className="motion-radius-label"><span id={`${id}-radius-label`}>Radius |μ| <b>{radius.toFixed(2)}</b></span><Slider aria-labelledby={`${id}-radius-label`} min={0} max={MAX_RADIUS} step={0.01} value={[radius]} onValueChange={(value) => { const r = Array.isArray(value) ? value[0] : value; choose({ re: r * Math.cos(angle), im: r * Math.sin(angle) }); }} /></div>
        <div className="motion-buttons"><Button variant="outline" size="sm" onClick={() => setPlaying(!playing)}>{playing ? <Pause /> : <Play />}{playing ? 'Pause' : 'Travel around the disk'}</Button><Button variant="outline" size="sm" onClick={() => choose(ZERO)}><RotateCcw /> μ = 0</Button></div>
        <p className="motion-note">The boundary |μ| = 1 is excluded. This numerical view stops at |μ| = 0.85.</p>
      </div>
      <section className="plane-panel motion-plane"><header><div><h3>{radius < 1e-10 ? 'M₀ = Mandelbrot set' : 'Connectedness locus Mμ'}</h3><span>Slice Per₁(μ) · coordinate q</span></div><div className="plot-zoom"><Button variant="outline" size="icon-sm" aria-label="Zoom in connectedness locus" onClick={() => setView(zoomView(view, view, 0.5, 120))}><Plus /></Button><Button variant="outline" size="icon-sm" aria-label="Zoom out connectedness locus" onClick={() => setView(zoomView(view, view, 2, 120))}><Minus /></Button><Button variant="outline" size="icon-sm" aria-label="Reset connectedness locus view" onClick={() => setView(PARAMETER_VIEW)}><RotateCcw /></Button></div></header>
        <FractalPlane mode="motion" c={ZERO} view={view} iterations={iterations} renderEscape={escape} onRendered={onRendered} />
        <label className="detail-control">Detail <select aria-label="Connectedness locus iteration limit" value={iterations} onChange={(event) => setIterations(Number(event.target.value))}><option value={100}>100 iterations</option><option value={180}>180 iterations</option><option value={350}>350 iterations</option></select></label>
      </section>
    </div>
    <p className="simulation-caption">A numerical illustration of holomorphic motion: each slice is recomputed from critical orbits. Individual points are not tracked by the holomorphic-motion map. Dark pixels are finite-iteration estimates, and parts of the set may lie outside the viewing window.</p>
    <details className="motion-method"><summary>Normalization, numerical method & credits</summary><p>This follows the connectedness loci described in the Research Statement. We use q = βγ/4, where β and γ are the other fixed-point multipliers; q = c when μ = 0. The representative is f(z) = z(z + β)/(1 + μz), with β² − (2 − μ + 4μq)β + 4q = 0. A point is coloured outside once both critical orbits pass the escape radius 2(|β| + 1)/(1 − |μ|). Increasing the iteration limit improves the approximation; it does not certify membership.</p><p>Mathematical sources: <a href="https://www.math.stonybrook.edu/preprints/ims12-08.pdf" target="_blank" rel="noreferrer">Berteloot–Gauthier, Theorem 2.4</a> (holomorphic motion); <a href="https://www.math.stonybrook.edu/preprints/ims12-02.pdf" target="_blank" rel="noreferrer">Milnor, §9</a> (normal form); <a href="https://arxiv.org/pdf/1109.0368" target="_blank" rel="noreferrer">Devaney–Fagella–Garijo–Jarque, Theorem 2.1</a> (critical-orbit criterion). The numerical implementation and coordinate choice are original to this site.</p></details>
  </section>;
}
