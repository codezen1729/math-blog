'use client';

/* oxlint-disable next/no-img-element -- Portable, source-provided images for the static Pages site. */
import { useEffect, useState } from 'react';
import { ArrowUpRight, Mail, MapPin, Pause, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const CV_URL = 'https://drive.google.com/file/d/1TGzDcNFihT8BUT7hoq-IACxKTAWOEhA5/view?usp=sharing';
export const ORIGINAL_SITE = 'https://sites.google.com/view/viswanathan1729/navigate';

export function PersonalHome() {
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => setPlaying(!window.matchMedia('(prefers-reduced-motion: reduce)').matches));
    return () => window.cancelAnimationFrame(frame);
  }, []);
  return (
    <main className="personal-home">
      <header className="personal-hero">
        <p className="kicker">Mathematics · Complex dynamics</p>
        <h1>S. Viswanathan</h1>
        <p className="hero-subtitle">My academic webpage</p>
      </header>
      <div className="home-profile-grid">
        <aside className="home-portrait-column">
          <figure className="home-photograph"><img src="profile/cathedral.jpg" alt="The twin spires of a Gothic cathedral, from my academic homepage." width="1175" height="2048" /><figcaption>From my academic homepage</figcaption></figure>
          <address className="home-contact"><p><Mail aria-hidden="true" /><a href="mailto:viswa@math.tifr.res.in">viswa@math.tifr.res.in</a></p><p><MapPin aria-hidden="true" /><span>Office A445<br />School of Mathematics</span></p></address>
        </aside>
        <div className="home-biography">
          <p className="biography-lead">I am a PhD Student at Tata Institute of Fundamental Research (ICTS-TIFR), working under the supervision of Sabyasachi Mukherjee. I am part of the <a href="https://randomgeometry.in/">random geometry group</a> there, and I specialise in dynamical systems, in particular, complex dynamics, and surgery theory.</p>
          <nav className="profile-quick-links" aria-label="Academic information"><a href="#/research">Research <ArrowUpRight aria-hidden="true" /></a><a href="#/vita">Vita & teaching <ArrowUpRight aria-hidden="true" /></a><a href="#/blog">Mathematical blog <ArrowUpRight aria-hidden="true" /></a></nav>
          <section className="home-motion">
            <div className="home-motion-title"><h2>From hyperbolic to parabolic</h2><Button variant="ghost" size="sm" onClick={() => setPlaying(value => !value)} aria-pressed={playing}>{playing ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />}{playing ? 'Pause' : 'Play'}</Button></div>
            <p>The following gif depicts a motion of the classical Mandelbrot set to the parabolic Mandelbrot set; essentially a walk from the world of hyperbolic external maps to parabolic external maps.</p>
            <figure className="home-motion-figure">{playing ? <img src="profile/mandelbrot-motion.gif" alt="An animation from my homepage showing the classical Mandelbrot set moving towards the parabolic Mandelbrot set." width="1280" height="644" /> : <div className="motion-paused"><Play aria-hidden="true" /><span>Animation paused</span></div>}<figcaption><span>Animation from <a href={ORIGINAL_SITE}>my original homepage</a></span><a href="#/lab">Explore the Laboratory <ArrowUpRight aria-hidden="true" /></a></figcaption></figure>
          </section>
        </div>
      </div>
    </main>
  );
}

export function VitaPage() {
  return (
    <main className="personal-page vita-page">
      <header className="personal-page-heading"><div><p className="kicker">Academic life</p><h1>Vita</h1></div><a className="text-action" href={CV_URL} target="_blank" rel="noreferrer">Full curriculum vitae <ArrowUpRight aria-hidden="true" /></a></header>
      <nav className="section-links" aria-label="Vita sections"><a href="#/vita" onClick={e => { e.preventDefault(); document.getElementById('education')?.scrollIntoView({ behavior: 'smooth' }); }}>Education</a><a href="#/vita" onClick={e => { e.preventDefault(); document.getElementById('teaching')?.scrollIntoView({ behavior: 'smooth' }); }}>Teaching</a><a href="#/vita" onClick={e => { e.preventDefault(); document.getElementById('honors')?.scrollIntoView({ behavior: 'smooth' }); }}>Honors</a><a href="#/vita" onClick={e => { e.preventDefault(); document.getElementById('skills')?.scrollIntoView({ behavior: 'smooth' }); }}>Skills</a></nav>
      <section className="vita-section" id="education"><h2>Education</h2><div className="vita-entries">
        <article><span className="vita-date">2022 —</span><div><h3>PhD, Mathematics</h3><p><a href="https://main.tifr.res.in/">Tata Institute of Fundamental Research</a></p></div></article>
        <article><span className="vita-date">2020 — 2022</span><div><h3>M.Sc. Mathematics</h3><p><a href="https://www.ksom.res.in/">Kerala School of Mathematics</a>, Kozhikode</p></div></article>
        <article><span className="vita-date">2016 — 2019</span><div><h3>B.Sc. (Hons), Mathematics and Computer Science</h3><p><a href="https://www.cmi.ac.in/">Chennai Mathematical Institute</a>, Chennai</p></div></article>
      </div></section>
      <section className="vita-section" id="teaching"><h2>Teaching</h2><div className="vita-entries">
        <article><span className="vita-date">2025</span><div><h3>Complex Dynamics</h3><p>Teaching Assistant for a mini-course in the <a href="https://www.atmschools.org/school/2025/AIS/tcaohd">Advanced Instructional School, Topics in Complex Analysis in one and Higher Dimensions</a>, IIT Palakkad.</p></div></article>
        <article><span className="vita-date">2025</span><div><h3>Potential Theory</h3><p>Teaching Assistant for a mini-course in the <a href="https://www.mathweb.tifr.res.in/vigyan-vidushi.html">Vigyan Vidushi Program</a>, TIFR Mumbai.</p></div></article>
        <article><span className="vita-date">2024</span><div><h3>Graduate Algebra</h3><p>Teaching Assistant at TIFR CAM.</p></div></article>
      </div></section>
      <section className="vita-section" id="honors"><h2>Honors</h2><div className="vita-entries">
        <article><span className="vita-date">2015 — 2018</span><div><h3>National Board for Higher Mathematics Fellowship</h3><p>Fellowship from National Board for Higher Mathematics, India, awarded based on the performance in INMO.</p></div></article>
        <article><span className="vita-date">2015, 2016</span><div><h3>International Mathematics Olympiad Training Camp</h3><p>Attended IMOTC at Homi Bhabha Centre for Science Education, TIFR, Mumbai.</p></div></article>
        <article><span className="vita-date">2015</span><div><h3>Indian National Mathematics Olympiad</h3><p>Qualified INMO.</p></div></article>
      </div></section>
      <section className="vita-section" id="skills"><h2>Skills & learning</h2><div className="vita-entries"><p>Languages: Python, LaTeX.</p><article><span className="vita-date">2026</span><div><h3><a href="https://www.coursera.org/account/accomplishments/verify/BEZKSBXMPOCW">Advanced Learning Algorithms <ArrowUpRight aria-hidden="true" /></a></h3><p>Certified by DeepLearning.AI, Stanford Online.</p></div></article><article><span className="vita-date">2026</span><div><h3><a href="https://www.coursera.org/account/accomplishments/verify/95D009VSO86T">Supervised Machine Learning <ArrowUpRight aria-hidden="true" /></a></h3><p>Certified by DeepLearning.AI, Stanford Online.</p></div></article></div></section>
      <p className="personal-source">Based on my <a href={`${ORIGINAL_SITE}/vita`}>Vita</a> and <a href={`${ORIGINAL_SITE}/teaching`}>Teaching</a> pages.</p>
    </main>
  );
}

export function PersonalResearchPage() {
  return (
    <main className="personal-page personal-research-page">
      <header className="personal-page-heading"><div><p className="kicker">Complex dynamics & geometry</p><h1>Research</h1></div><a className="text-action" href="#/research/statement">Research statement <ArrowUpRight aria-hidden="true" /></a></header>
      <section className="research-interests"><h2>Research interests</h2><ul><li>Complex Dynamics</li><li>Teichmüller Theory</li><li>Hyperbolic Geometry</li><li>Ergodic Theory</li></ul></section>
      <section className="research-papers"><h2>Papers & preprints</h2>
        <article className="paper-entry"><span className="paper-number">01</span><div><h3><a href="https://arxiv.org/abs/2508.18711">Correspondences on hyperelliptic surfaces, combination theorems, and Hurwitz spaces</a></h3><p>Joint work with Sabyasachi Mukherjee.</p><a className="paper-link" href="https://arxiv.org/abs/2508.18711">arXiv:2508.18711 <ArrowUpRight aria-hidden="true" /></a></div></article>
        <article className="paper-entry"><span className="paper-number">02</span><div><h3>Hausdorff Dimensions, Matings, and Markov Maps</h3><p>With Zhiqiang Li, Sabyasachi Mukherjee, and Yifan Yin.</p><span className="paper-status">In preparation</span></div></article>
        <article className="paper-entry"><span className="paper-number">03</span><div><h3>Dynamical Motion of the Parabolic Mandelbrot Set</h3><p>With Sabyasachi Mukherjee.</p><span className="paper-status">In preparation</span></div></article>
      </section>
      <section className="thesis-section"><p className="kicker">Master’s thesis project</p><h2><a href="https://drive.google.com/file/d/1PT3fJpv12HyykBggnQCWnqLFzbvPM0XP/view?usp=sharing">Surgeries in Complex Dynamic <ArrowUpRight aria-hidden="true" /></a></h2><p className="thesis-supervisor">Under the supervision of Sabyasachi Mukherjee</p><div className="thesis-abstract"><p>The thesis is an expose on three classical surgeries in complex dynamics. The first one is the proof of Sullivan&apos;s No Wandering Theorem, which leads up to the classification of the connected components of the Fatou set. The second one establishes the fact that the multiplier map on the hyperbolic components of a Multibrot set is a conformal isomorphism; this in its essence describes the topological shape of such sets modulo the hyperbolicity conjecture. The last one, due to McMullen, leads to the proof of the finiteness of the modular group associated to connected, forward invariant components of the Julia set.</p></div></section>
      <p className="personal-source">From my <a href={`${ORIGINAL_SITE}/research`}>research webpage</a>.</p>
    </main>
  );
}
