'use client';

/* oxlint-disable next/no-img-element -- Portable, source-provided images for the static Pages site. */
import { useEffect, useState } from 'react';
import { Pause, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export const CV_URL = 'https://drive.google.com/file/d/1TGzDcNFihT8BUT7hoq-IACxKTAWOEhA5/view?usp=sharing';

export function PersonalPageBanner({ title }: { title: string }) {
  return <header className="original-home-banner"><div className="original-title-frame"><h1>{title}</h1></div></header>;
}

export function PersonalContact() {
  return <footer className="original-contact-footer"><address className="original-contact-content"><h2>Contact Information</h2><p>Office: A445, School of Mathematics<br />email: <a href="mailto:viswa@math.tifr.res.in">viswa@math.tifr.res.in</a></p></address></footer>;
}

export function PersonalHome() {
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => setPlaying(!window.matchMedia('(prefers-reduced-motion: reduce)').matches));
    return () => window.cancelAnimationFrame(frame);
  }, []);
  return <main className="original-home">
    <PersonalPageBanner title="My Academic Webpage" />
    <div className="original-home-content">
      <div className="original-home-grid">
        <img className="original-home-photo" src="profile/cathedral.jpg" alt="The twin spires of a Gothic cathedral." width="1175" height="2048" />
        <div className="original-home-biography">
          <p>I am a PhD Student at Tata Institute of Fundamental Research (ICTS-TIFR), working under the supervision of Sabyasachi Mukherjee. I am part of the <a href="https://randomgeometry.in/">random geometry group</a> there, and I specialise in dynamical systems, in particular, complex dynamics, and surgery theory.</p>
          <p>The following gif depicts a motion of the classical Mandelbrot set to the parabolic Mandelbrot set; essentially a walk from the world of hyperbolic external maps to parabolic external maps.</p>
          <div className={`original-home-animation ${playing ? 'is-playing' : 'is-paused'}`}>
            {playing ? <img src="profile/mandelbrot-motion.gif" alt="The classical Mandelbrot set moving towards the parabolic Mandelbrot set." width="1280" height="644" /> : <div className="original-animation-paused"><Play aria-hidden="true" /><span>Animation paused</span></div>}
            <Button className="original-animation-control" variant="ghost" size="sm" onClick={() => setPlaying(value => !value)} aria-label={playing ? 'Pause animation' : 'Play animation'}>{playing ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />}{playing ? 'Pause' : 'Play'}</Button>
          </div>
        </div>
      </div>
    </div>
  </main>;
}

export function VitaPage() {
  return (
    <main className="original-personal-page vita-page">
      <PersonalPageBanner title="Vita" />
      <div className="original-page-content">
        <Accordion multiple hiddenUntilFound className="original-sections">
          <AccordionItem value="education" id="education"><AccordionTrigger>Education</AccordionTrigger><AccordionContent className="original-section-text"><ul>
            <li>PhD, Mathematics, <a href="https://main.tifr.res.in/">Tata Institute of Fundamental Research</a>, 2022 —.</li>
            <li>M.Sc. Mathematics, <a href="https://www.ksom.res.in/">Kerala School of Mathematics</a>, Kozhikode, 2020 — 2022.</li>
            <li>B.Sc. (Hons), Mathematics and Computer Science, <a href="https://www.cmi.ac.in/">Chennai Mathematical Institute</a>, Chennai, 2016 — 2019.</li>
          </ul></AccordionContent></AccordionItem>
          <AccordionItem value="teaching" id="teaching"><AccordionTrigger>Teaching</AccordionTrigger><AccordionContent className="original-section-text"><ul>
            <li>Teaching Assistant for a mini-course in Complex Dynamics in the <a href="https://www.atmschools.org/school/2025/AIS/tcaohd">Advanced Instructional School, Topics in Complex Analysis in one and Higher Dimensions</a>, IIT Palakkad, 2025.</li>
            <li>Teaching Assistant for a mini-course in Potential Theory in the <a href="https://www.mathweb.tifr.res.in/vigyan-vidushi.html">Vigyan Vidushi Program</a>, TIFR Mumbai, 2025.</li>
            <li>Teaching Assistant for Graduate Algebra at TIFR CAM, 2024.</li>
          </ul></AccordionContent></AccordionItem>
          <AccordionItem value="honors" id="honors"><AccordionTrigger>Honors</AccordionTrigger><AccordionContent className="original-section-text"><ul>
            <li>Fellowship from National Board for Higher Mathematics, India, awarded based on the performance in INMO, 2015 — 2018.</li>
            <li>Attended International Mathematics Olympiad Training Camp (IMOTC) at Homi Bhabha Centre for Science Education, TIFR, Mumbai, 2015, 2016.</li>
            <li>Qualified Indian National Mathematics Olympiad (INMO), 2015.</li>
          </ul></AccordionContent></AccordionItem>
          <AccordionItem value="skills" id="skills"><AccordionTrigger>Skills</AccordionTrigger><AccordionContent className="original-section-text"><ul>
            <li><a href="https://www.coursera.org/account/accomplishments/verify/BEZKSBXMPOCW">Advanced Learning Algorithms</a>, certified by DeepLearning.AI, Stanford Online, 2026.</li>
            <li><a href="https://www.coursera.org/account/accomplishments/verify/95D009VSO86T">Supervised Machine Learning</a>, certified by DeepLearning.AI, Stanford Online, 2026.</li>
            <li><a href="https://proceedings.mlr.press/v326/suk26a.html">Neural Network for Aerodynamic Design</a>, published in the Proceedings of Machine Learning Research, 2026.</li>
          </ul></AccordionContent></AccordionItem>
        </Accordion>
        <p className="original-page-link">Here&apos;s my full <a href={CV_URL} target="_blank" rel="noreferrer">CV</a>.</p>
      </div>
    </main>
  );
}

export function PersonalResearchPage() {
  return (
    <main className="original-personal-page personal-research-page">
      <PersonalPageBanner title="Research" />
      <div className="original-page-content">
        <Accordion multiple hiddenUntilFound className="original-sections">
          <AccordionItem value="interests"><AccordionTrigger>Research Interests</AccordionTrigger><AccordionContent className="original-section-text"><ul><li>Complex Dynamics</li><li>Teichmüller Theory</li><li>Hyperbolic Geometry</li><li>Ergodic Theory.</li></ul></AccordionContent></AccordionItem>
          <AccordionItem value="papers"><AccordionTrigger>Papers/Preprints</AccordionTrigger><AccordionContent className="original-section-text"><ol>
            <li><a href="https://arxiv.org/abs/2508.18711">Correspondences on hyperelliptic surfaces, combination theorems, and Hurwitz spaces</a> (joint work with Sabyasachi Mukherjee).</li>
            <li>Hausdorff Dimensions, Matings, and Markov Maps (in preparation, with Zhiqiang Li, Sabyasachi Mukherjee, and Yifan Yin)</li>
            <li>Dynamical Motion of the Parabolic Mandelbrot Set (in preparation, with Sabyasachi Mukherjee)</li>
          </ol></AccordionContent></AccordionItem>
          <AccordionItem value="thesis"><AccordionTrigger>Master&apos;s Thesis Project</AccordionTrigger><AccordionContent className="original-section-text">
            <p>Title: Surgeries in Complex Dynamics</p>
            <p>Abstract: The thesis is an expose on three classical surgeries in complex dynamics. The first one is the proof of Sullivan&apos;s No Wandering Theorem, which leads up to the classification of the connected components of the Fatou set. The second one establishes the fact that the multiplier map on the hyperbolic components of a Multibrot set is a conformal isomorphism; this in its essence describes the topological shape of such sets modulo the hyperbolicity conjecture. The last one, due to McMullen, leads to the proof of the finiteness of the modular group associated to connected, forward invariant components of the Julia set.</p>
            <p>(under the supervision of Sabyasachi Mukherjee)</p>
          </AccordionContent></AccordionItem>
        </Accordion>
      </div>
    </main>
  );
}
