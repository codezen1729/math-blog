'use client';

/* oxlint-disable next/no-img-element -- Relative archive assets must work in both the Vite GitHub Pages build and the local Next preview. */

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import katex from 'katex';
import {
  ArrowLeft,
  ArrowRight,
  ChevronDown,
  Clock3,
  FileText,
  FlaskConical,
  Menu,
  Orbit,
  Search,
  X,
} from 'lucide-react';
import postsJson from '@/lib/generated-posts.json';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { LatticeExplorer } from '@/components/simulations';
import { MandelbrotJuliaExplorer } from '@/components/dynamics-explorer';
import { MandelbrotMotion } from '@/components/mandelbrot-motion';

type Post = {
  order: number;
  slug: string;
  title: string;
  dek: string;
  excerptHtml?: string;
  mathMacros?: Record<string, string>;
  phase: number;
  phaseLabel: string;
  track: string;
  kind: string;
  minutes: number;
  wordCount: number;
  prerequisites: string[];
  background?: string[];
  sourceCollection: string;
  sourcePath: string;
  sourceStart: number;
  sourceEnd: number;
  sourceUrl?: string;
  status: string;
  html: string;
};

type TocItem = { id: string; text: string; level: number };

// The generated records are validated by scripts/check-content.mjs.
const posts = postsJson as unknown as Post[];
const essays = posts.filter((post) => post.track !== 'Research');
const researchPost = posts.find((post) => post.track === 'Research') ?? posts[posts.length - 1];
const tracks = Array.from(new Set(essays.map((post) => post.track)));

const romanPhases = ['I', 'II', 'III', 'IV', 'V'];
const katexMacros = {
  '\\C': '\\mathbb{C}', '\\R': '\\mathbb{R}', '\\Q': '\\mathbb{Q}', '\\Z': '\\mathbb{Z}', '\\N': '\\mathbb{N}', '\\D': '\\mathbb{D}', '\\T': '\\mathbb{T}',
  '\\Res': '\\operatorname{Res}', '\\Int': '\\operatorname{Int}', '\\Ext': '\\operatorname{Ext}', '\\supp': '\\operatorname{supp}',
  '\\xlongrightarrow': '\\xrightarrow', '\\qed': '\\square',
};
const phaseNotes: Record<number, string> = {
  1: 'The analytic toolkit: geometry of the complex plane, contour methods, winding, and covering spaces.',
  2: 'Compact surfaces, branched covers, elliptic curves, periods, Jacobians, and Abelian functions.',
  3: 'Bundles and stable structures, from local triviality to Bott periodicity and generalized cohomology.',
  4: 'Iteration and statistical mechanics: Julia sets, quasiconformal surgery, entropy, pressure, and dimension.',
  5: 'The research program connecting Kleinian groups, correspondences, parameter spaces, and conformal dynamics.',
};

const trackFigures: Record<string, Array<{ src: string; caption: string }>> = {
  'Complex analysis': [
    { src: 'figures/complex-analysis/note3-fig-09.webp', caption: 'Contour geometry from the supplied Complex Analysis Notes.' },
    { src: 'figures/complex-analysis/note7-fig-03.webp', caption: 'A source figure from the supplied notes on Laurent series and residues.' },
  ],
  'Riemann surfaces': [
    { src: 'figures/abels-theorem/polygon.webp', caption: 'A cut polygon from the supplied Abel’s Theorem exposition.' },
  ],
  'Elliptic curves': [
    { src: 'figures/elliptic-curves/torus.webp', caption: 'A torus illustration from the supplied Elliptic Curves source.' },
    { src: 'figures/elliptic-curves/lattices.webp', caption: 'Lattices in the complex plane from the supplied source archive.' },
  ],
  'Abelian functions': [
    { src: 'figures/abels-theorem/polygon.webp', caption: 'The canonical polygon used in the supplied discussion of periods.' },
  ],
  'K-theory': [
    { src: 'figures/k-theory/hopf-fibration.webp', caption: 'Hopf fibration image imported from the supplied K-Theory archive.' },
    { src: 'figures/k-theory/universal-line-bundle.webp', caption: 'Universal line-bundle image from the supplied K-Theory archive.' },
  ],
  'Complex dynamics': [
    { src: 'figures/surgeries/j1.webp', caption: 'A Julia set from the supplied Surgeries in Complex Dynamics archive.' },
    { src: 'figures/surgeries/m.webp', caption: 'The Mandelbrot set from the supplied complex-dynamics archive.' },
  ],
  'Thermodynamic formalism': [
    { src: 'figures/research-statement/fractals.webp', caption: 'Fractal geometry from the supplied Research Statement figures.' },
  ],
  Research: [
    { src: 'figures/research-statement/correspondence-plane.webp', caption: 'Correspondence plane from the supplied Research Statement.' },
  ],
};

function readHashRoute() {
  return window.location.hash.replace(/^#\/?/, '') || 'home';
}

function subscribeToHashRoute(onStoreChange: () => void) {
  window.addEventListener('hashchange', onStoreChange);
  return () => window.removeEventListener('hashchange', onStoreChange);
}

function useHashRoute() {
  return useSyncExternalStore(subscribeToHashRoute, readHashRoute, () => 'home');
}

function figureFor(post: Post, index = 0) {
  const choices = trackFigures[post.track] ?? trackFigures['Complex analysis'];
  return choices[index % choices.length];
}

function MetaLine({ post }: { post: Post }) {
  return (
    <p className="post-meta">
      <span>Essay {String(post.order).padStart(2, '0')}</span>
      <span>{post.track}</span>
      <span><Clock3 aria-hidden="true" /> {post.minutes} min read</span>
    </p>
  );
}

function SiteHeader({ onSearch }: { onSearch: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const links = [
    ['home', 'Home'],
    ['path', 'Reading path'],
    ['archive', 'Archive'],
    ['lab', 'Simulations'],
    ['research', 'Research'],
    ['credits', 'Credits'],
  ];
  return (
    <>
      <header className="weblog-header">
        <div className="weblog-title-wrap">
          <a href="#/home" className="weblog-title">The Iterated Plane</a>
          <p>Expositions in analysis, geometry, topology, and dynamics</p>
        </div>
      </header>
      <nav className="weblog-nav" aria-label="Primary navigation">
        <div className={`nav-inner ${mobileOpen ? 'is-open' : ''}`}>
          <Button className="mobile-menu" variant="ghost" size="sm" aria-expanded={mobileOpen} onClick={() => setMobileOpen((value) => !value)}>
            {mobileOpen ? <X /> : <Menu />} Menu
          </Button>
          <div className="nav-links">
            {links.map(([href, label]) => <a key={href} href={`#/${href}`} onClick={() => setMobileOpen(false)}>{label}</a>)}
          </div>
          <Button className="nav-search" variant="ghost" size="sm" onClick={onSearch} aria-label="Search essays">
            <Search aria-hidden="true" /> Search <kbd>⌘K</kbd>
          </Button>
        </div>
      </nav>
    </>
  );
}

function SiteFooter() {
  return (
    <footer className="weblog-footer">
      <div>
        <span className="footer-mark"><Orbit aria-hidden="true" /></span>
        <div><strong>The Iterated Plane</strong><p>A mathematical notebook by S. Viswanathan</p></div>
      </div>
      <p>Built from the supplied TeX archive. Equations rendered with KaTeX; simulations computed locally in your browser.</p>
    </footer>
  );
}

function SearchPanel({ open, setOpen }: { open: boolean; setOpen: (value: boolean) => void }) {
  const [query, setQuery] = useState('');
  const results = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return essays.slice(0, 8);
    return posts.filter((post) => `${post.title} ${post.track} ${post.dek} ${post.sourceCollection}`.toLowerCase().includes(value)).slice(0, 12);
  }, [query]);
  return (
    <Dialog open={open} onOpenChange={(nextOpen) => { if (!nextOpen) setQuery(''); setOpen(nextOpen); }}>
      <DialogContent className="search-dialog">
        <DialogHeader>
          <DialogTitle>Search the notebook</DialogTitle>
          <DialogDescription>Find an essay by idea, theorem, or branch of mathematics.</DialogDescription>
        </DialogHeader>
        <div className="search-field-wrap"><Search aria-hidden="true" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try “Riemann”, “entropy”, or “bundles”…" aria-label="Search essays" /></div>
        <div className="search-results" aria-label="Search results">
          {results.map((post) => (
            <a key={post.slug} href={post.track === 'Research' ? '#/research' : `#/post/${post.slug}`} onClick={() => setOpen(false)}>
              <span>{String(post.order).padStart(2, '0')}</span>
              <div><strong>{post.title}</strong><small>{post.track} · {post.minutes} min</small></div>
              <ArrowRight aria-hidden="true" />
            </a>
          ))}
          {!results.length && <p className="empty-search">No essays match “{query}”.</p>}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Sidebar({ onSearch }: { onSearch: () => void }) {
  const trackCounts = tracks.map((track) => ({ track, count: essays.filter((post) => post.track === track).length }));
  return (
    <aside className="weblog-sidebar" aria-label="Blog sidebar">
      <section className="sidebar-widget start-widget">
        <h2>Start here</h2>
        <p>{essays.length} substantial essays, arranged from foundations to more advanced subjects.</p>
        <a className="sidebar-action" href={`#/post/${essays[0].slug}`}>Begin with Essay 01 <ArrowRight aria-hidden="true" /></a>
      </section>
      <section className="sidebar-widget">
        <h2>Search</h2>
        <button className="sidebar-search" onClick={onSearch}><Search aria-hidden="true" /> Search this notebook</button>
      </section>
      <section className="sidebar-widget">
        <h2>Categories</h2>
        <ul className="sidebar-list categories-list">
          {trackCounts.map(({ track, count }) => <li key={track}><a href={`#/archive?track=${encodeURIComponent(track)}`}>{track}</a><span>{count}</span></li>)}
        </ul>
      </section>
      <section className="sidebar-widget lab-widget">
        <h2>Interactive laboratory</h2>
        <div className="lab-orbit" aria-hidden="true"><i /><i /><i /><i /><b /></div>
        <p>Vary a quadratic map, watch a Julia set appear, or deform a complex lattice.</p>
        <a href="#/lab">Open the simulations »</a>
      </section>
      <section className="sidebar-widget">
        <h2>The reading path</h2>
        <ol className="sidebar-path">
          {[1, 2, 3, 4].map((phase) => (
            <li key={phase}><span>{romanPhases[phase - 1]}</span><a href={`#/path?phase=${phase}`}>{posts.find((post) => post.phase === phase)?.phaseLabel}</a></li>
          ))}
        </ol>
      </section>
      <section className="sidebar-widget">
        <h2>About the archive</h2>
        <p>The essays are selected passages from the original TeX manuscripts, without added exposition. Source drafts retain the author’s wording and need mathematical review.</p>
        <a href="#/credits">Sources & credits »</a>
      </section>
    </aside>
  );
}

function PostTeaser({ post, imageIndex = 0, prominent = false }: { post: Post; imageIndex?: number; prominent?: boolean }) {
  const figure = figureFor(post, imageIndex);
  return (
    <article className={`post-teaser ${prominent ? 'post-teaser-prominent' : ''}`}>
      <header>
        <h2><a href={`#/post/${post.slug}`}>{post.title}</a></h2>
        <MetaLine post={post} />
      </header>
      {prominent && (
        <figure className="teaser-figure">
          <img src={figure.src} alt={figure.caption} />
          <figcaption>{figure.caption} <a href="#/credits">Credit details</a></figcaption>
        </figure>
      )}
      {post.excerptHtml && <div className="teaser-copy source-excerpt" dangerouslySetInnerHTML={{ __html: renderMathFragments(post.excerptHtml, post.mathMacros) }} />}
      <div className="teaser-bottom">
        <a className="read-more" href={`#/post/${post.slug}`}>Continue reading »</a>
        <span>{post.status}</span>
      </div>
    </article>
  );
}

function BlogHome({ onSearch }: { onSearch: () => void }) {
  const selected = ['Complex analysis', 'Elliptic curves', 'Abelian functions', 'Complex dynamics'].map((track) => essays.find((post) => post.track === track)).filter((post): post is Post => Boolean(post));
  return (
    <main className="simulation-home">
      <header className="home-lab-intro"><div><p className="kicker">A mathematical notebook by S. Viswanathan</p><h1>Explore the dynamics.</h1></div><a href="#/path">Go to the essays <ArrowRight /></a></header>
      <div className="front-laboratory"><MandelbrotJuliaExplorer /><MandelbrotMotion /></div>
      <div className="weblog-columns home-columns">
      <div className="weblog-main">
        <div className="section-rule"><span>Selected essays</span></div>
        {selected.map((post, index) => <PostTeaser key={post.slug} post={post} prominent={index === 1 || index === 3} imageIndex={index} />)}
        <nav className="older-entries"><a href="#/archive">« Browse the complete archive</a><a href="#/path">Next: the reading path »</a></nav>
      </div>
      <Sidebar onSearch={onSearch} />
      </div>
    </main>
  );
}

function ReadingPath({ route }: { route: string }) {
  const phases = [1, 2, 3, 4];
  useEffect(() => {
    const phase = new URLSearchParams(route.split('?')[1] ?? '').get('phase');
    if (!phase) return;
    const frame = window.requestAnimationFrame(() => document.getElementById(`phase-${phase}`)?.scrollIntoView({ behavior: 'smooth' }));
    return () => window.cancelAnimationFrame(frame);
  }, [route]);
  return (
    <div className="weblog-columns">
      <main className="weblog-main archive-main">
        <header className="page-intro">
          <p className="kicker">Curriculum</p>
          <h1>The reading path</h1>
          <p>A suggested order through the selected manuscripts. Each essay lists its own background; independent subjects need not be read in sequence.</p>
          <div className="path-summary"><span><strong>{essays.length}</strong> essays</span><span><strong>{Math.round(essays.reduce((sum, post) => sum + post.minutes, 0) / 60)}</strong> reading hours</span><span><strong>8</strong> source manuscripts</span></div>
        </header>
        {phases.map((phase) => {
          const phasePosts = essays.filter((post) => post.phase === phase);
          return (
            <section className="path-phase" key={phase} id={`phase-${phase}`}>
              <header><span>{romanPhases[phase - 1]}</span><div><p>Movement {romanPhases[phase - 1]}</p><h2>{phasePosts[0]?.phaseLabel}</h2><small>{phaseNotes[phase]}</small></div></header>
              <ol className="path-essay-list" start={phasePosts[0]?.order}>
                {phasePosts.map((post) => (
                  <li key={post.slug} value={post.order}>
                    <a href={`#/post/${post.slug}`}><strong>{post.title}</strong><span>{post.track} · {post.minutes} min</span></a>
                  </li>
                ))}
              </ol>
            </section>
          );
        })}
      </main>
      <Sidebar onSearch={() => window.dispatchEvent(new CustomEvent('open-site-search'))} />
    </div>
  );
}

function ArchivePage({ onSearch, route }: { onSearch: () => void; route: string }) {
  const requestedTrack = new URLSearchParams(route.split('?')[1] ?? '').get('track');
  const [track, setTrack] = useState(requestedTrack && tracks.includes(requestedTrack) ? requestedTrack : 'All subjects');
  const [query, setQuery] = useState('');
  const filtered = essays.filter((post) => (track === 'All subjects' || post.track === track) && (!query || `${post.title} ${post.dek}`.toLowerCase().includes(query.toLowerCase())));
  return (
    <div className="weblog-columns">
      <main className="weblog-main archive-main">
        <header className="page-intro compact-intro"><p className="kicker">Index</p><h1>Essay archive</h1><p>All source-derived essays, searchable by title and mathematical track.</p></header>
        <div className="archive-tools">
          <label><span className="sr-only">Search the archive</span><Search aria-hidden="true" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search essays…" /></label>
          <label><span className="sr-only">Filter by subject</span><select value={track} onChange={(event) => setTrack(event.target.value)}><option>All subjects</option>{tracks.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown aria-hidden="true" /></label>
        </div>
        <p className="archive-count">Showing {filtered.length} of {essays.length} essays</p>
        <ol className="archive-list">
          {filtered.map((post) => (
            <li key={post.slug}>
              <span>{String(post.order).padStart(2, '0')}</span>
              <div><h2><a href={`#/post/${post.slug}`}>{post.title}</a></h2><small>{post.phaseLabel} · {post.track} · {post.minutes} min</small></div>
            </li>
          ))}
        </ol>
      </main>
      <Sidebar onSearch={onSearch} />
    </div>
  );
}

function decodeHtmlEntities(value: string) {
  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 10)));
}

function renderMathFragments(source: string, sourceMacros: Record<string, string> = {}) {
  return source.replace(/<span class="math (inline|display)">([\s\S]*?)<\/span>/g, (full, mode: 'inline' | 'display', encodedMath: string) => {
    const displayMode = mode === 'display';
    const decoded = decodeHtmlEntities(encodedMath.trim());
    const delimiters = displayMode
      ? [['\\[', '\\]'], ['$$', '$$']]
      : [['\\(', '\\)'], ['$', '$']];
    const match = delimiters.find(([left, right]) => decoded.startsWith(left) && decoded.endsWith(right));
    const math = match ? decoded.slice(match[0].length, -match[1].length) : decoded;
    try {
      return `<span class="math ${mode}">${katex.renderToString(math, { displayMode, throwOnError: false, strict: false, macros: { ...katexMacros, ...sourceMacros } })}</span>`;
    } catch {
      return full;
    }
  });
}

function prepareArticleHtml(source: string, sourceMacros: Record<string, string> = {}) {
  const toc: TocItem[] = [];
  const seen = new Map<string, number>();
  const html = source.replace(/<h([2-4])([^>]*)>([\s\S]*?)<\/h\1>/gi, (full, rawLevel: string, rawAttributes: string, body: string) => {
    const level = Number(rawLevel);
    const text = body
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim() || 'Section';
    const existingId = rawAttributes.match(/\sid=(['"])(.*?)\1/i)?.[2];
    const base = existingId || text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'section';
    const number = seen.get(base) ?? 0;
    seen.set(base, number + 1);
    const id = existingId || (number ? `${base}-${number + 1}` : base);
    if (toc.length < 14) toc.push({ id, text, level });
    const attributes = existingId ? rawAttributes : `${rawAttributes} id="${id}"`;
    return `<h${level}${attributes}>${body}</h${level}>`;
  });
  return { html: renderMathFragments(html, sourceMacros), toc };
}

function ArticleBody({ post }: { post: Post }) {
  const ref = useRef<HTMLDivElement>(null);
  const prepared = useMemo(() => prepareArticleHtml(post.html, post.mathMacros), [post.html, post.mathMacros]);
  useEffect(() => {
    const article = ref.current;
    if (!article) return;
    const followInternalLink = (event: MouseEvent) => {
      const link = (event.target as Element | null)?.closest('a');
      const href = link?.getAttribute('href');
      if (!href?.startsWith('#') || href.startsWith('#/')) return;
      const target = document.getElementById(decodeURIComponent(href.slice(1)));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    article.addEventListener('click', followInternalLink);
    return () => article.removeEventListener('click', followInternalLink);
  }, [post.slug, post.html]);
  return (
    <>
      <aside className="article-toc" aria-label="On this page">
        <p>On this page</p>
        {prepared.toc.length ? <ol>{prepared.toc.map((item) => <li key={item.id} className={`toc-level-${item.level}`}><a href={`#/post/${post.slug}`} onClick={(event) => { event.preventDefault(); document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}>{item.text}</a></li>)}</ol> : <span>This field note has no internal headings.</span>}
      </aside>
      <div ref={ref} className="article-prose" dangerouslySetInnerHTML={{ __html: prepared.html }} />
    </>
  );
}

function ArticlePage({ post }: { post: Post }) {
  const index = essays.findIndex((item) => item.slug === post.slug);
  const previous = index > 0 ? essays[index - 1] : undefined;
  const next = index >= 0 && index < essays.length - 1 ? essays[index + 1] : undefined;
  return (
    <main className="article-page">
      <div className="article-progress" aria-hidden="true"><span style={{ width: `${Math.max(1, (post.order / essays.length) * 100)}%` }} /></div>
      <div className="article-breadcrumb"><a href="#/path"><ArrowLeft /> Reading path</a><span>Movement {romanPhases[post.phase - 1]} · {post.phaseLabel}</span></div>
      <article>
        <header className="article-header">
          <p className="kicker">{post.kind} {String(post.order).padStart(2, '0')}</p>
          <h1>{post.title}</h1>
          <MetaLine post={post} />
        </header>
        <aside className="editorial-note"><FileText aria-hidden="true" /><div><strong>Editorial note · source draft</strong><p>A selected manuscript passage, without new exposition. Original mathematical claims are retained and require the author’s review.</p></div></aside>
        {(post.prerequisites.length > 0 || Boolean(post.background?.length)) && <aside className="reading-background"><strong>Reading guide · background</strong><p>{post.prerequisites.map((slug, n) => { const prerequisite = essays.find((entry) => entry.slug === slug); return prerequisite ? <span key={slug}>{n > 0 ? ' · ' : ''}<a href={`#/post/${slug}`}>{prerequisite.title}</a></span> : null; })}{post.prerequisites.length > 0 && Boolean(post.background?.length) ? ' · ' : ''}{post.background?.join(' · ')}</p></aside>}
        <div className="article-layout"><ArticleBody post={post} /></div>
        <section className="source-note"><p className="kicker">From the archive</p><h2>{post.sourceCollection}</h2><p>Selected from <code>{post.sourcePath}</code>, lines {post.sourceStart}–{post.sourceEnd}. Typesetting and navigation are editorial; the exposition is the author’s. {post.sourceUrl && <a href={post.sourceUrl} download>Read the original TeX</a>}</p></section>
        <nav className="article-next-prev" aria-label="Adjacent essays">
          {previous ? <a href={`#/post/${previous.slug}`}><span><ArrowLeft /> Previous</span><strong>{previous.title}</strong></a> : <span />}
          {next ? <a href={`#/post/${next.slug}`}><span>Next <ArrowRight /></span><strong>{next.title}</strong></a> : <a href="#/research"><span>Continue <ArrowRight /></span><strong>Research frontiers</strong></a>}
        </nav>
      </article>
    </main>
  );
}

function LabPage() {
  return (
    <main className="lab-page">
      <header className="page-intro lab-intro"><p className="kicker">Interactive mathematics</p><h1>The laboratory</h1><p>Move the parameters. The figures are computed here—not fetched, filmed, or pre-rendered—so every change is a new mathematical experiment.</p></header>
      <MandelbrotJuliaExplorer />
      <MandelbrotMotion />
      <LatticeExplorer />
      <section className="lab-method"><FlaskConical aria-hidden="true" /><div><h2>About these simulations</h2><p>The simulations are original code and run in your browser. Mathematical references and numerical limitations are given alongside the connectedness-locus explorer. The lattice explorer draws ℤ+τℤ from the chosen τ.</p></div></section>
    </main>
  );
}

function ResearchPage() {
  const figures = trackFigures.Research;
  return (
    <main className="research-page">
      <header className="research-hero">
        <div><p className="kicker">S. Viswanathan</p><h1>Research Statement</h1></div>
        <figure><img src={figures[0].src} alt={figures[0].caption} /><figcaption>{figures[0].caption}</figcaption></figure>
      </header>
      <article className="research-article">
        <aside className="research-summary"><h2>Research themes</h2><ul><li>Algebraic correspondences</li><li>Kleinian groups and matings</li><li>Teichmüller and parameter spaces</li><li>Entropy and Hausdorff dimension</li></ul></aside>
        <div className="article-layout"><ArticleBody post={researchPost} /></div>
      </article>
    </main>
  );
}

function CreditsPage() {
  return (
    <main className="credits-page">
      <header className="page-intro"><p className="kicker">Provenance</p><h1>Sources & credits</h1><p>A clear ledger for the words, pictures, mathematical rendering, simulations, and visual references used throughout the site.</p></header>
      <section><h2>Manuscripts</h2><p>The {essays.length} essay bodies are contiguous passages from the TeX projects supplied by S. Viswanathan. There is no added mathematical exposition. Titles come from the sources; excerpts on the front page repeat manuscript paragraphs. Reading guides, source notices, and simulation descriptions are separately identified website material. The complete original archive is preserved privately by the author; this public edition contains only the selected passages and the pictures displayed on the site.</p></section>
      <section><h2>Figures</h2><p>Every in-article picture currently comes from the supplied TeX archive; no photograph or mathematical illustration was downloaded from the internet for this edition. Captions identify the originating manuscript. Some legacy raster files contain no embedded provenance or licence information, so their rights should be confirmed before the site is made public.</p>
        <ul className="credit-list"><li>Complex Analysis Notes — 23 source-rendered figures</li><li>Elliptic Curves — 7 supplied raster figures and 3 source diagrams</li><li>K-Theory — 2 supplied raster figures and 24 source diagrams</li><li>Surgeries in Complex Dynamics — 5 supplied raster figures and 14 source diagrams</li><li>Research Statement — 7 supplied raster figures</li><li>Topology of Surfaces — 3 source diagrams</li><li>Abel’s Theorem — 1 supplied polygon figure</li></ul>
      </section>
      <section><h2>Interactive mathematics</h2><p>The Mandelbrot–Julia explorer, multiplier-slice explorer, and lattice simulation are original code, with no downloaded imagery or external datasets. The multiplier-slice explorer credits <a href="https://www.math.stonybrook.edu/preprints/ims12-08.pdf">Berteloot–Gauthier</a>, <a href="https://www.math.stonybrook.edu/preprints/ims12-02.pdf">Milnor</a>, and <a href="https://arxiv.org/pdf/1109.0368">Devaney–Fagella–Garijo–Jarque</a> for its mathematical foundations. Finite computation is not a proof of set membership.</p></section>
      <section><h2>Design reference</h2><p>The essay-first hierarchy, centered paper surface, masthead, archive, and right-hand reference column were inspired by <a href="https://gowers.wordpress.com/" target="_blank" rel="noreferrer">Gowers’s Weblog</a>. The typography, palette, responsive behavior, simulations, and all site components are original to this project.</p></section>
      <section><h2>Rendering</h2><p>Mathematical notation is rendered with KaTeX. The social-sharing card is an original generated asset created for The Iterated Plane.</p></section>
    </main>
  );
}

function NotFound() {
  return <main className="not-found"><Orbit /><p className="kicker">404</p><h1>This orbit escaped.</h1><p>The requested essay is not in the archive.</p><a href="#/home">Return to the weblog</a></main>;
}

export function SiteApp() {
  const route = useHashRoute();
  const [searchOpen, setSearchOpen] = useState(false);
  const previousRoute = useRef(route);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.isContentEditable;
      if ((!typing && event.key === '/') || ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k')) {
        event.preventDefault(); setSearchOpen(true);
      }
    };
    const onCustom = () => setSearchOpen(true);
    window.addEventListener('keydown', onKey);
    window.addEventListener('open-site-search', onCustom);
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('open-site-search', onCustom); };
  }, []);

  useEffect(() => {
    const previousPage = previousRoute.current.split('?')[0];
    const currentPage = route.split('?')[0];
    previousRoute.current = route;
    if (previousPage === currentPage) return;
    window.scrollTo({ top: 0, behavior: 'auto' });
    const frame = window.requestAnimationFrame(() => {
      const heading = document.querySelector<HTMLElement>('.weblog-page main h1');
      if (heading) {
        heading.tabIndex = -1;
        heading.focus({ preventScroll: true });
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, [route]);

  useEffect(() => {
    let pageTitle = 'The Iterated Plane';
    if (route.startsWith('post/')) {
      const slug = route.slice('post/'.length).split('?')[0];
      pageTitle = essays.find((item) => item.slug === slug)?.title ?? pageTitle;
    } else if (route.startsWith('path')) pageTitle = 'Reading path';
    else if (route.startsWith('archive')) pageTitle = 'Essay archive';
    else if (route === 'lab') pageTitle = 'Interactive laboratory';
    else if (route === 'research') pageTitle = 'Research profile';
    else if (route === 'credits') pageTitle = 'Sources & credits';
    document.title = pageTitle === 'The Iterated Plane' ? 'The Iterated Plane · S. Viswanathan' : `${pageTitle} · The Iterated Plane`;
  }, [route]);

  let content: React.ReactNode;
  if (route === 'home' || route === '') content = <BlogHome onSearch={() => setSearchOpen(true)} />;
  else if (route.startsWith('path')) content = <ReadingPath route={route} />;
  else if (route.startsWith('archive')) content = <ArchivePage key={route} onSearch={() => setSearchOpen(true)} route={route} />;
  else if (route === 'lab') content = <LabPage />;
  else if (route === 'research') content = <ResearchPage />;
  else if (route === 'credits') content = <CreditsPage />;
  else if (route.startsWith('post/')) {
    const slug = route.slice('post/'.length).split('?')[0];
    const post = essays.find((item) => item.slug === slug);
    content = post ? <ArticlePage post={post} /> : <NotFound />;
  } else content = <NotFound />;

  return (
    <div className="site-background">
      <div className="weblog-page">
        <SiteHeader onSearch={() => setSearchOpen(true)} />
        {content}
        <SiteFooter />
      </div>
      <SearchPanel open={searchOpen} setOpen={setSearchOpen} />
    </div>
  );
}
