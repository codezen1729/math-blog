'use client';

/* oxlint-disable next/no-img-element -- Relative archive assets must work in both the Vite GitHub Pages build and the local Next preview. */

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import katex from 'katex';
import {
  ArrowLeft,
  ArrowRight,
  Clock3,
  FlaskConical,
  Menu,
  Orbit,
  Search,
  X,
} from 'lucide-react';
import postsJson from '@/lib/generated-posts.json';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { MandelbrotJuliaExplorer } from '@/components/dynamics-explorer';
import { MandelbrotMotion } from '@/components/mandelbrot-motion';
import { PersonalHome, VitaPage, PersonalResearchPage, ORIGINAL_SITE } from '@/components/personal-pages';
import figureMetadataJson from '@/lib/figure-metadata.json';

type Post = {
  order: number;
  slug: string;
  title: string;
  dek: string;
  excerptHtml?: string;
  mathMacros?: Record<string, string>;
  phase: number;
  phaseLabel: string;
  track: string;
  kind: string;
  minutes: number;
  wordCount: number;
  prerequisites: string[];
  background?: string[];
  sourceCollection: string;
  sourcePath: string;
  sourceStart: number;
  sourceEnd: number;
  sourceSegments?: {source: string; start: number; end: number; sha256: string}[];
  sourceUrl?: string;
  status: string;
  html: string;
};

type TocItem = { id: string; text: string; level: number };

// The generated records are validated by scripts/check-content.mjs.
const posts = postsJson as unknown as Post[];
const essays = posts.filter((post) => post.track !== 'Research');
const researchPost = posts.find((post) => post.track === 'Research') ?? posts[posts.length - 1];
const series = [
  { slug: 'structures', title: 'Structures', phase: 3, description: 'Bundles · Stable structures · K-theory', figure: 'figures/k-theory/hopf-fibration.webp' },
  { slug: 'dynamics', title: 'Dynamics', phase: 4, description: 'Iteration · Surgery · Dimension', figure: 'figures/surgeries/j1.webp' },
  { slug: 'surfaces-and-curves', title: 'Surfaces and Curves', phase: 2, description: 'Topology · Elliptic curves · Abelian functions', figure: 'figures/elliptic-curves/torus.webp' },
  { slug: 'standard-tools', title: 'Standard Tools in Complex Analysis', phase: 1, description: 'Geometry · Contours · Holomorphic functions', figure: 'figures/complex-analysis/note3-fig-09.svg' },
];
type FigureInfo = { kind: string; width: number; height: number; displayWidth: number };
const figureMetadata = figureMetadataJson as Record<string, FigureInfo>;
function seriesFor(post: Post) { return series.find(item => item.phase === post.phase); }
function enlargedFigureWidth(src: string) { const info = figureMetadata[src]; return info?.kind === 'raster' ? info.width : Math.max(600, info?.width ?? 800); }
const katexMacros = {
  '\\C': '\\mathbb{C}', '\\R': '\\mathbb{R}', '\\Q': '\\mathbb{Q}', '\\Z': '\\mathbb{Z}', '\\N': '\\mathbb{N}', '\\D': '\\mathbb{D}', '\\T': '\\mathbb{T}',
  '\\Res': '\\operatorname{Res}', '\\Int': '\\operatorname{Int}', '\\Ext': '\\operatorname{Ext}', '\\supp': '\\operatorname{supp}',
  '\\xlongrightarrow': '\\xrightarrow', '\\qed': '\\square',
};
function readHashRoute() {
  return window.location.hash.replace(/^#\/?/, '') || 'home';
}

function subscribeToHashRoute(onStoreChange: () => void) {
  window.addEventListener('hashchange', onStoreChange);
  return () => window.removeEventListener('hashchange', onStoreChange);
}

function useHashRoute() {
  return useSyncExternalStore(subscribeToHashRoute, readHashRoute, () => 'home');
}

function MetaLine({ post }: { post: Post }) {
  return (
    <p className="post-meta">
      <span>{seriesFor(post)?.title ?? 'Research'}</span>
      <span><Clock3 aria-hidden="true" /> {post.minutes} min read</span>
    </p>
  );
}

function SiteHeader({ onSearch, route }: { onSearch: () => void; route: string }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const links = [
    ['home', 'Home'],
    ['vita', 'Vita'],
    ['research', 'Research'],
    ['lab', 'Laboratory'],
    ['blog', 'Blog'],
  ];
  return (
    <>
      <header className="academic-header">
        <a href="#/home" className="academic-wordmark">S. Viswanathan<span>Mathematics</span></a>
        <nav className={`academic-nav ${mobileOpen ? 'is-open' : ''}`} aria-label="Primary navigation">
          <Button className="mobile-menu" variant="ghost" size="sm" aria-expanded={mobileOpen} onClick={() => setMobileOpen((value) => !value)}>
            {mobileOpen ? <X /> : <Menu />} Menu
          </Button>
          <div className="academic-links">
            {links.map(([href, label]) => <a key={href} href={`#/${href}`} aria-current={route.split('/')[0].split('?')[0] === href || (href === 'blog' && /^(post|path|archive)/.test(route)) ? 'page' : undefined} onClick={() => setMobileOpen(false)}>{label}</a>)}
          </div>
          <Button className="nav-search" variant="ghost" size="sm" onClick={onSearch} aria-label="Search essays">
            <Search aria-hidden="true" /> Search <kbd>⌘K</kbd>
          </Button>
        </nav>
      </header>
    </>
  );
}

function SiteFooter() {
  return (
    <footer className="academic-footer">
      <div>
        <strong>S. Viswanathan</strong><span>Complex dynamics · ICTS–TIFR</span>
      </div>
      <nav aria-label="Footer"><a href="mailto:viswa@math.tifr.res.in">Contact</a><a href="#/credits">Sources & credits</a><a href="https://github.com/codezen1729/math-blog">GitHub</a></nav>
    </footer>
  );
}

function SearchPanel({ open, setOpen }: { open: boolean; setOpen: (value: boolean) => void }) {
  const [query, setQuery] = useState('');
  const results = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return essays.slice(0, 8);
    return posts.filter((post) => `${post.title} ${post.track} ${post.dek} ${post.sourceCollection}`.toLowerCase().includes(value)).slice(0, 12);
  }, [query]);
  return (
    <Dialog open={open} onOpenChange={(nextOpen) => { if (!nextOpen) setQuery(''); setOpen(nextOpen); }}>
      <DialogContent className="search-dialog">
        <DialogHeader>
          <DialogTitle>Search the blog</DialogTitle>
          <DialogDescription>Find an essay by idea, theorem, or branch of mathematics.</DialogDescription>
        </DialogHeader>
        <div className="search-field-wrap"><Search aria-hidden="true" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try “Riemann”, “entropy”, or “bundles”…" aria-label="Search essays" /></div>
        <div className="search-results" aria-label="Search results">
          {results.map((post) => (
            <a key={post.slug} href={post.track === 'Research' ? '#/research/statement' : `#/post/${post.slug}`} onClick={() => setOpen(false)}>
              <span>{String(post.order).padStart(2, '0')}</span>
              <div><strong>{post.title}</strong><small>{post.track} · {post.minutes} min</small></div>
              <ArrowRight aria-hidden="true" />
            </a>
          ))}
          {!results.length && <p className="empty-search">No essays match “{query}”.</p>}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function BlogPage({ route }: { route: string }) {
  const requested = route.split('?')[0].split('/')[1];
  const oldTrack = new URLSearchParams(route.split('?')[1]).get('track');
  const active = series.find(item => item.slug === requested) ?? (oldTrack ? seriesFor(essays.find(post => post.track === oldTrack) ?? essays[0]) : undefined);
  const selected = active ? essays.filter(post => post.phase === active.phase) : [];
  return <main className="personal-page blog-page">
    <header className="personal-page-heading"><div><p className="kicker">Mathematical expositions</p><h1>{active?.title ?? 'Blog'}</h1></div>{active && <a className="text-action" href="#/blog"><ArrowLeft aria-hidden="true" /> All series</a>}</header>
    <p className="blog-introduction">{active ? 'Read in order, with background noted at the beginning of each piece.' : 'Selected expositions, arranged into four reading sequences.'}</p>
    <nav className="series-tabs" aria-label="Blog series">{series.map(item => <a key={item.slug} href={`#/blog/${item.slug}`} aria-current={active?.slug === item.slug ? 'page' : undefined}>{item.title}</a>)}</nav>
    {active ? <ol className="series-posts">{selected.map((post, index) => <li key={post.slug}><span className="series-part">{String(index + 1).padStart(2, '0')}</span><div><p className="series-source">{post.sourceCollection} · {post.minutes} min read</p><h2><a href={`#/post/${post.slug}`}>{post.title}</a></h2>{post.excerptHtml && <div className="source-excerpt" dangerouslySetInnerHTML={{ __html: renderMathFragments(post.excerptHtml, post.mathMacros) }} />}<a className="read-post" href={`#/post/${post.slug}`}>Read part {index + 1} <ArrowRight aria-hidden="true" /></a></div></li>)}</ol> :
      <div className="series-grid">{series.map((item, index) => <a className={`series-card series-card-${item.slug}`} key={item.slug} href={`#/blog/${item.slug}`} aria-label={item.title}><figure><img src={item.figure} alt="" loading="lazy" /></figure><div><p className="kicker">Series {String(index + 1).padStart(2, '0')} · {essays.filter(post => post.phase === item.phase).length} pieces</p><h2>{item.title}</h2><p>{item.description}</p><span>Read the series <ArrowRight aria-hidden="true" /></span></div></a>)}</div>}
    <p className="blog-editorial-note">The mathematical writing is taken from my manuscripts. Only selection, typesetting, and reading guides are editorial; the passages retain their source-draft status.</p>
  </main>;
}

function decodeHtmlEntities(value: string) {
  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 10)));
}

function renderMathFragments(source: string, sourceMacros: Record<string, string> = {}) {
  return source.replace(/<span class="math (inline|display)">([\s\S]*?)<\/span>/g, (full, mode: 'inline' | 'display', encodedMath: string) => {
    const displayMode = mode === 'display';
    const decoded = decodeHtmlEntities(encodedMath.trim());
    const delimiters = displayMode
      ? [['\\[', '\\]'], ['$$', '$$']]
      : [['\\(', '\\)'], ['$', '$']];
    const match = delimiters.find(([left, right]) => decoded.startsWith(left) && decoded.endsWith(right));
    const math = match ? decoded.slice(match[0].length, -match[1].length) : decoded;
    try {
      return `<span class="math ${mode}">${katex.renderToString(math, { displayMode, throwOnError: false, strict: false, macros: { ...katexMacros, ...sourceMacros } })}</span>`;
    } catch {
      return full;
    }
  });
}

function prepareArticleHtml(source: string, sourceMacros: Record<string, string> = {}, articleTitle = 'the manuscript') {
  const toc: TocItem[] = [];
  const seen = new Map<string, number>();
  let html = source.replace(/<h([2-4])([^>]*)>([\s\S]*?)<\/h\1>/gi, (full, rawLevel: string, rawAttributes: string, body: string) => {
    const level = Number(rawLevel);
    const text = body
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim() || 'Section';
    const existingId = rawAttributes.match(/\sid=(['"])(.*?)\1/i)?.[2];
    const base = existingId || text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'section';
    const number = seen.get(base) ?? 0;
    seen.set(base, number + 1);
    const id = existingId || (number ? `${base}-${number + 1}` : base);
    if (toc.length < 14) toc.push({ id, text, level });
    const attributes = existingId ? rawAttributes : `${rawAttributes} id="${id}"`;
    return `<h${level}${attributes}>${body}</h${level}>`;
  });
  const captions = new Map<string, string>();
  for (const figure of source.matchAll(/<figure\b[^>]*>([\s\S]*?)<\/figure>/g)) {
    const caption = figure[1].match(/<figcaption>([\s\S]*?)<\/figcaption>/)?.[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    if (caption) for (const picture of figure[1].matchAll(/src="([^"]+)"/g)) captions.set(picture[1], decodeHtmlEntities(caption));
  }
  let imageNumber = 0;
  const escapeAttribute = (value: string) => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');
  html = html.replace(/<img\b([^>]*)>/g, (full, attributes: string) => {
    const src = attributes.match(/src="([^"]+)"/)?.[1];
    if (!src) return full;
    const info = figureMetadata[decodeHtmlEntities(src)];
    imageNumber++;
    const caption = captions.get(src) || 'Figure ' + imageNumber + ' from ' + articleTitle;
    let clean = attributes.replace(/\s(?:style|width|height)="[^"]*"/g, '');
    if (!/\salt="[^"]+"/.test(clean)) clean = clean.replace(/\salt=""/, '') + ' alt="' + escapeAttribute(caption) + '"';
    const dimensions = info ? ` width="${Math.round(info.width)}" height="${Math.round(info.height)}" style="width:${info.displayWidth}px;max-width:100%;height:auto"` : '';
    return `<a class="figure-zoom" href="${src}" target="_blank" rel="noreferrer" aria-label="Enlarge: ${escapeAttribute(caption)}"><img${clean}${dimensions}></a>`;
  });
  return { html: renderMathFragments(html, sourceMacros), toc };
}

function ArticleBody({ post }: { post: Post }) {
  const ref = useRef<HTMLDivElement>(null);
  const [enlarged, setEnlarged] = useState<{src: string; alt: string} | null>(null);
  const prepared = useMemo(() => prepareArticleHtml(post.html, post.mathMacros, post.title), [post.html, post.mathMacros, post.title]);
  useEffect(() => {
    const article = ref.current;
    if (!article) return;
    const followInternalLink = (event: MouseEvent) => {
      const link = (event.target as Element | null)?.closest('a');
      const href = link?.getAttribute('href');
      if (link?.classList.contains('figure-zoom') && href && !event.metaKey && !event.ctrlKey) { event.preventDefault(); setEnlarged({src: href, alt: link.querySelector('img')?.alt || 'Manuscript figure'}); return; }
      if (!href?.startsWith('#') || href.startsWith('#/')) return;
      const target = document.getElementById(decodeURIComponent(href.slice(1)));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    article.addEventListener('click', followInternalLink);
    return () => article.removeEventListener('click', followInternalLink);
  }, [post.slug, post.html]);
  return (
    <>
      <aside className="article-toc" aria-label="On this page">
        <p>On this page</p>
        {prepared.toc.length ? <ol>{prepared.toc.map((item) => <li key={item.id} className={`toc-level-${item.level}`}><a href={`#/post/${post.slug}`} onClick={(event) => { event.preventDefault(); document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}>{item.text}</a></li>)}</ol> : <span>This passage has no internal headings.</span>}
      </aside>
      <div ref={ref} className="article-prose" dangerouslySetInnerHTML={{ __html: prepared.html }} />
      <Dialog open={Boolean(enlarged)} onOpenChange={open => { if (!open) setEnlarged(null); }}><DialogContent className="figure-dialog"><DialogHeader><DialogTitle>Manuscript figure</DialogTitle><DialogDescription>Original proportions. Scroll to inspect wide diagrams, or open the full-size file.</DialogDescription></DialogHeader>{enlarged && <><div className="enlarged-figure"><img src={enlarged.src} alt={enlarged.alt} style={{width: enlargedFigureWidth(enlarged.src)}} /></div><a href={enlarged.src} target="_blank" rel="noreferrer">Open full-size figure ↗</a></>}</DialogContent></Dialog>
    </>
  );
}

function ArticlePage({ post }: { post: Post }) {
  const group = seriesFor(post);
  const sequence = essays.filter(item => item.phase === post.phase);
  const index = sequence.findIndex(item => item.slug === post.slug);
  const previous = sequence[index - 1];
  const next = sequence[index + 1];
  return (
    <main className="article-page">
      <div className="article-breadcrumb"><a href={`#/blog/${group?.slug ?? ''}`}><ArrowLeft /> {group?.title ?? 'Blog'}</a><span>Part {index + 1} of {sequence.length}</span></div>
      <article>
        <header className="article-header">
          <p className="kicker">Part {String(index + 1).padStart(2, '0')}</p>
          <h1>{post.title}</h1>
          <MetaLine post={post} />
        </header>
        <p className="source-draft-note">Source draft · Original manuscript wording, without added exposition.</p>
        {(post.prerequisites.length > 0 || Boolean(post.background?.length)) && <aside className="reading-background"><strong>Reading guide · background</strong><p>{post.prerequisites.map((slug, n) => { const prerequisite = essays.find((entry) => entry.slug === slug); return prerequisite ? <span key={slug}>{n > 0 ? ' · ' : ''}<a href={`#/post/${slug}`}>{prerequisite.title}</a></span> : null; })}{post.prerequisites.length > 0 && Boolean(post.background?.length) ? ' · ' : ''}{post.background?.join(' · ')}</p></aside>}
        <div className="article-layout"><ArticleBody post={post} /></div>
        <section className="source-note"><p className="kicker">From the archive</p><h2>{post.sourceCollection}</h2><p>Selected from <code>{post.sourcePath}</code>, lines {(post.sourceSegments ?? [{start: post.sourceStart, end: post.sourceEnd}]).map(segment => `${segment.start}–${segment.end}`).join(' and ')}. Typesetting and navigation are editorial; the exposition is the author’s.</p></section>
        <nav className="article-next-prev" aria-label="Adjacent essays">
          {previous ? <a href={`#/post/${previous.slug}`}><span><ArrowLeft /> Previous</span><strong>{previous.title}</strong></a> : <span />}
          {next ? <a href={`#/post/${next.slug}`}><span>Next <ArrowRight /></span><strong>{next.title}</strong></a> : <a href="#/blog"><span>Continue <ArrowRight /></span><strong>Explore the other series</strong></a>}
        </nav>
      </article>
    </main>
  );
}

function LabPage() {
  return (
    <main className="lab-page">
      <header className="page-intro lab-intro"><p className="kicker">Interactive mathematics</p><h1>Laboratory</h1><p>Explore parameter spaces, Julia sets, and orbits.</p></header>
      <MandelbrotJuliaExplorer />
      <MandelbrotMotion />
      <section className="lab-method"><FlaskConical aria-hidden="true" /><div><h2>About these simulations</h2><p>The simulations are original code and run in your browser. Mathematical references and numerical limitations are given alongside the connectedness-locus explorer.</p></div></section>
    </main>
  );
}

function ResearchPage() {
  return (
    <main className="research-page">
      <header className="research-hero">
        <div><p className="kicker">S. Viswanathan</p><h1>Research Statement</h1></div>
        <a className="text-action" href="#/research"><ArrowLeft aria-hidden="true" /> Research overview</a>
      </header>
      <article className="research-article">
        <aside className="research-summary"><h2>Research themes</h2><ul><li>Algebraic correspondences</li><li>Kleinian groups and matings</li><li>Teichmüller and parameter spaces</li><li>Entropy and Hausdorff dimension</li></ul></aside>
        <div className="article-layout"><ArticleBody post={researchPost} /></div>
      </article>
    </main>
  );
}

function CreditsPage() {
  return <main className="credits-page">
    <header className="page-intro"><p className="kicker">Provenance</p><h1>Sources & credits</h1></header>
    <section><h2>Writing</h2><p>The {essays.length} blog pieces are contiguous selections from the TeX manuscripts supplied by S. Viswanathan. No mathematical exposition has been added. Titles are drawn from the sources; preview paragraphs repeat the manuscript text. Reading guides and source notices are separately identified website material. Full manuscripts and private editorial notes are not included in the public edition.</p></section>
    <section><h2>Academic information & homepage images</h2><p>The biography, contact details, Vita, Teaching, Research, cathedral photograph, geometric banner, and Mandelbrot animation come from <a href={ORIGINAL_SITE}>my original academic webpage</a>. The animation is distinct from the numerical, browser-generated plots in the Laboratory.</p></section>
    <section><h2>Mathematical figures</h2><p>Article figures come from the supplied manuscripts. The updated Complex Analysis figures and the commutative diagrams are typeset from their original TeX as resolution-independent SVGs. Raster illustrations retain their original proportions and are displayed without enlargement beyond their intended reading size. Click a figure to inspect the full-size file.</p><p>Some older raster illustrations do not carry individual creator or licence information in the supplied files. Their originating manuscript is recorded beside each article; no additional authorship or licence claim is made here.</p></section>
    <section><h2>Laboratory</h2><p>The simulations are original browser code. The multiplier-slice explorer credits <a href="https://www.math.stonybrook.edu/preprints/ims12-08.pdf">Berteloot–Gauthier</a>, <a href="https://www.math.stonybrook.edu/preprints/ims12-02.pdf">Milnor</a>, and <a href="https://arxiv.org/pdf/1109.0368">Devaney–Fagella–Garijo–Jarque</a> for its mathematical foundations. These finite numerical approximations are not proofs of membership or a computation of a pointwise holomorphic motion.</p></section>
    <section><h2>Design & rendering</h2><p>The personal layout is inspired by <a href={ORIGINAL_SITE}>my Google Sites homepage</a> and <a href="https://willierushrush.github.io/">Willie Rush’s webpage</a>. The original blog took inspiration from <a href="https://gowers.wordpress.com/">Gowers’s Weblog</a>. Site components, responsive styling, and simulations were built for this project. Mathematics is rendered with KaTeX and native TeX-generated vector diagrams. The social-sharing card is an AI-generated design made for this website.</p></section>
  </main>;
}

function NotFound() {
  return <main className="not-found"><Orbit /><p className="kicker">404</p><h1>This orbit escaped.</h1><p>The requested essay is not in the archive.</p><a href="#/home">Return home</a></main>;
}

export function SiteApp() {
  const route = useHashRoute();
  const [searchOpen, setSearchOpen] = useState(false);
  const previousRoute = useRef(route);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.isContentEditable;
      if ((!typing && event.key === '/') || ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k')) {
        event.preventDefault(); setSearchOpen(true);
      }
    };
    const onCustom = () => setSearchOpen(true);
    window.addEventListener('keydown', onKey);
    window.addEventListener('open-site-search', onCustom);
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('open-site-search', onCustom); };
  }, []);

  useEffect(() => {
    const previousPage = previousRoute.current.split('?')[0];
    const currentPage = route.split('?')[0];
    previousRoute.current = route;
    if (previousPage === currentPage) return;
    window.scrollTo({ top: 0, behavior: 'auto' });
    const frame = window.requestAnimationFrame(() => {
      const heading = document.querySelector<HTMLElement>('.weblog-page main h1');
      if (heading) {
        heading.tabIndex = -1;
        heading.focus({ preventScroll: true });
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, [route]);

  useEffect(() => {
    const page = route.split('?')[0];
    const post = page.startsWith('post/') ? essays.find(item => item.slug === page.slice(5)) : undefined;
    const group = series.find(item => page === `blog/${item.slug}`);
    const titles: Record<string, string> = {vita: 'Vita', research: 'Research', 'research/statement': 'Research statement', lab: 'Laboratory', blog: 'Blog', path: 'Blog', archive: 'Blog', credits: 'Sources & credits'};
    const title = post?.title ?? group?.title ?? titles[page];
    document.title = title ? `${title} · S. Viswanathan` : 'S. Viswanathan · Mathematics';
  }, [route]);

  let content: React.ReactNode;
  if (route === 'home' || route === '') content = <PersonalHome />;
  else if (/^(blog|path|archive)([/?]|$)/.test(route)) content = <BlogPage route={route} />;
  else if (route === 'vita') content = <VitaPage />;
  else if (route === 'lab') content = <LabPage />;
  else if (route === 'research') content = <PersonalResearchPage />;
  else if (route === 'research/statement' || route === 'post/research-statement') content = <ResearchPage />;
  else if (route === 'credits') content = <CreditsPage />;
  else if (route.startsWith('post/')) {
    const slug = route.slice('post/'.length).split('?')[0];
    const post = essays.find((item) => item.slug === slug);
    content = post ? <ArticlePage post={post} /> : <NotFound />;
  } else content = <NotFound />;

  return (
    <div className="site-background">
      <div className="weblog-page">
        <SiteHeader route={route} onSearch={() => setSearchOpen(true)} />
        {content}
        <SiteFooter />
      </div>
      <SearchPanel open={searchOpen} setOpen={setSearchOpen} />
    </div>
  );
}
