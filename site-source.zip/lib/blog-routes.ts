export const personalWebpage = 'https://sites.google.com/view/viswanathan1729/navigate';
export const blogTitle = 'The Iteration Café';
export const blogSubtitle = 'a math blog by S. Viswanathan';
export const blogDescription = 'Mathematical writing by S. Viswanathan: K-theory, complex dynamics, commutative algebra, ergodic theory, surfaces and curves, and tools in complex analysis.';

export function blogPageMetadata(title?: string, description = blogDescription, article = false) {
  return { title: title ? `${title} · ${blogTitle}` : blogTitle, description, type: article ? 'article' : 'website', useSiteImage: !article };
}

export function normalizeBlogRoute(hash: string): string {
  const route = hash.replace(/^#\/?/, '');
  const [page, query] = route.split('?');
  const suffix = query ? `?${query}` : '';
  if (!page || /^home\/?$/.test(page)) return `blog${suffix}`;
  if (/^(path|archive)(\/|$)/.test(page)) return `${page.replace(/^(path|archive)/, 'blog')}${suffix}`;
  return route;
}
