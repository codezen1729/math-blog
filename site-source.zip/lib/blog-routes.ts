export const personalWebpage = 'https://sites.google.com/view/viswanathan1729/navigate';
export const blogTitle = 'The Iteration Café';
export const blogSubtitle = 'a math blog by S. Viswanathan';
export const blogDescription = 'Mathematical writing by S. Viswanathan: K-theory, complex dynamics, commutative algebra, ergodic theory, surfaces and curves, and tools in complex analysis.';

export function blogPageMetadata(title?: string, description = blogDescription, article = false) {
  return { title: title ? `${title} · ${blogTitle}` : blogTitle, description, type: article ? 'article' : 'website', useSiteImage: !article };
}

const legacyTrackPhases: Record<string, number> = {
  'complex analysis': 1,
  'riemann surfaces': 2,
  'elliptic curves': 2,
  'abelian functions': 2,
  'surfaces and curves': 2,
  structures: 3,
  'k-theory': 3,
  'complex dynamics': 4,
  'thermodynamic formalism': 4,
  'commutative algebra': 5,
  'ergodic theory': 6,
  'the lemma book': 7,
  'lemma book (olympiad days)': 7,
  miscellaneous: 8,
};

export function phaseForLegacyTrack(track: string): number | undefined {
  return legacyTrackPhases[track.trim().toLowerCase()];
}

export function normalizeBlogRoute(hash: string): string {
  const route = hash.replace(/^#\/?/, '');
  const [page, query] = route.split('?');
  const suffix = query ? `?${query}` : '';
  if (!page || /^home\/?$/.test(page)) return `blog${suffix}`;
  if (/^recommendations\/?$/.test(page)) return `blog${suffix}`;
  if (/^(path|archive)(\/|$)/.test(page)) return `${page.replace(/^(path|archive)/, 'blog')}${suffix}`;
  return route;
}
