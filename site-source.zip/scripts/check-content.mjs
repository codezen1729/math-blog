import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import katex from 'katex';

const root = new URL('../', import.meta.url);
const publicRelease = process.argv.includes('--public');
if (publicRelease) {
  for (const path of ['_source/', 'EDITORIAL_REVIEW.md', 'scripts/curation.json', 'public/manuscripts/']) {
    assert.ok(!existsSync(new URL(path, root)), `Private material in public release: ${path}`);
  }
}
const posts = JSON.parse(readFileSync(new URL('lib/generated-posts.json', root), 'utf8'));
const bySlug = new Map(posts.map(post => [post.slug, post]));
const decode = value => value.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&#x([\da-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))).replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(+n));
const mathIssues=[];
const requiredPassages = {
  'vector-bundles': ['A paracompact Hasudorff space is normal and also admits a partition of unity'],
  'classification-vector-bundles': ['holds homotopic information about', 'is orthogonal'],
  'first-surgery': ['have no wandering Fatou components'],
  'locally-trivial-bundles': ['replacing points'],
};
let figures=0, equations=0;
assert.equal(bySlug.size, posts.length);
assert.equal(posts.filter(post=>post.track!=='Research').length,21);
for(const post of posts) {
  if (publicRelease) {
    assert.ok(!post.sourceUrl, `Full manuscript download in public release: ${post.slug}`);
    assert.ok(!/manuscripts\/|file:\/\/|\/Users\//.test(JSON.stringify(post)), `Private reference in ${post.slug}`);
  } else {
    const source=readFileSync(new URL(`_source/${post.sourcePath}`,root),'utf8');
    const lines=source.match(/[^\n]*\n|[^\n]+$/g);
    const excerpt=lines.slice(post.sourceStart-1,post.sourceEnd).join('');
    assert.equal(createHash('sha256').update(excerpt).digest('hex'),post.sourceSha256,post.slug);
    assert.equal(readFileSync(new URL(`public/${post.sourceUrl}`,root),'utf8'),source);
  }
  assert.ok(post.wordCount>250, `${post.slug} is an unexpectedly short fragment`);
  assert.equal(post.dek,'');
  assert.ok(post.excerptHtml === '' || post.html.includes(post.excerptHtml));
  assert.ok(!/the cited result|preserved in the linked TeX source|A technique-led field note/.test(post.html));
  for(const passage of requiredPassages[post.slug] ?? []) assert.ok(decode(post.html).includes(passage), `Missing source passage in ${post.slug}: ${passage}`);
  if(post.slug==='classification-vector-bundles') assert.ok(post.html.includes('\\tag{1}'));
  if(post.slug==='bott-periodicity-k-theory') for(const n of [2,3,4]) assert.ok(post.html.includes(`\\tag{${n}}`));
  for(const slug of post.prerequisites) assert.ok(bySlug.has(slug) && bySlug.get(slug).order<post.order,`Invalid prerequisite ${slug}`);
  for(const match of post.html.matchAll(/src="([^"]+)"/g)) {
    assert.ok(existsSync(new URL(`public/${decode(match[1])}`,root)),`${post.slug}: missing ${match[1]}`);
    figures++;
  }
  for(const match of post.html.matchAll(/<span class="math (inline|display)">([\s\S]*?)<\/span>/g)) {
    equations++;
    const raw=decode(match[2]).replace(/^(?:\\\[|\\\()/,'').replace(/(?:\\\]|\\\))$/,'');
    try { katex.renderToString(raw,{displayMode:match[1]==='display',throwOnError:true,strict:false,macros:{'\\xlongrightarrow':'\\xrightarrow','\\qed':'\\square','\\supp':'\\operatorname{supp}',...post.mathMacros}}); }
    catch(error) { mathIssues.push({slug:post.slug,math:raw.slice(0,100),error:error.message.slice(0,180)}); }
  }
}
console.log(JSON.stringify({posts:posts.length,essays:21,figures,equations,checks:publicRelease?'public privacy, content, assets and typesetting':'source fidelity, content, assets and typesetting',result:'passed',mathIssues},null,2));
assert.equal(mathIssues.length,0,'All manuscript formulas should typeset without errors. This does not validate the mathematics.');
