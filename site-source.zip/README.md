# S. Viswanathan · Mathematics

Personal academic website: Home, Vita (including Teaching), Research, Laboratory, and a mathematical Blog in four series. The 28 selected essays include the twelve-part Standard Tools in Complex Analysis series.

The full manuscripts and private notes are not part of this public edition.

## Local preview

Requires Node.js 22.13 or newer and pnpm 10.

```sh
pnpm install --frozen-lockfile
pnpm dev:pages
```

## Build and checks

```sh
node scripts/check-content.mjs --public
node --experimental-strip-types --test scripts/dynamics.test.mjs
pnpm build:pages
```

The static site is generated in `dist-pages/`. Hash-based navigation and relative asset paths support GitHub Pages project URLs.

## GitHub Pages

In the repository's Settings → Pages, choose GitHub Actions as the publishing source. The included workflow checks and publishes updates pushed to `main` or `master`; it can also be run manually from the Actions tab.

## Content

Published essays are in `lib/generated-posts.json`, illustrations in `public/figures/`, and interactive mathematics in `components/` and `lib/dynamics.ts`. The numerical plots are finite approximations, not proofs of membership or pointwise holomorphic-motion computations. Dependencies retain their respective licences; no blanket licence is granted for the manuscripts or supplied figures.
